/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
/* <DESC>
 * CA cert in memory with OpenSSL to get an HTTPS page.
 * </DESC>
 */

/* This example uses the legacy and discouraged method. Use
   CURLOPT_CAINFO_BLOB instead, which is TLS backend agnostic. See the
   cainfo-blob.c example */

/* Requires: USE_OPENSSL */

#include <openssl/ssl.h>

#include <stdio.h>

#include <curl/curl.h>

#if defined(OPENSSL_IS_BORINGSSL) || defined(OPENSSL_IS_AWSLC)
typedef size_t ossl_valsize_t;
#else
typedef int ossl_valsize_t;
#endif

static size_t write_cb(char *ptr, size_t size, size_t nmemb, void *stream)
{
  fwrite(ptr, size, nmemb, (FILE *)stream);
  return nmemb * size;
}

static CURLcode sslctx_function(CURL *curl, void *sslctx, void *pointer)
{
  /** This example uses two (fake) certificates **/
  /* replace the XXX with the actual CA certificates */
  static const char mypem[] =
    "-----BEGIN CERTIFICATE-----\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "-----END CERTIFICATE-----\n"
    "-----BEGIN CERTIFICATE-----\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
    "-----END CERTIFICATE-----\n";

  CURLcode result = CURLE_ABORTED_BY_CALLBACK;
  BIO *cbio = NULL;
  X509_STORE *cts;
  ossl_valsize_t i;
  STACK_OF(X509_INFO) * inf;

  (void)curl;
  (void)pointer;

  cts = SSL_CTX_get_cert_store((SSL_CTX *)sslctx);
  if(!cts) {
    printf("SSL_CTX_get_cert_store() failed\n");
    goto out;
  }

  cbio = BIO_new_mem_buf(mypem, sizeof(mypem) - 1);
  if(!cbio) {
    printf("BIO_new_mem_buf() failed\n");
    goto out;
  }

  inf = PEM_X509_INFO_read_bio(cbio, NULL, NULL, NULL);
  if(!inf) {
    printf("PEM_X509_INFO_read_bio() failed\n");
    goto out;
  }

  for(i = 0; i < sk_X509_INFO_num(inf); i++) {
    X509_INFO *itmp = sk_X509_INFO_value(inf, i);
    if(itmp->x509) {
      X509_STORE_add_cert(cts, itmp->x509);
    }
    if(itmp->crl) {
      X509_STORE_add_crl(cts, itmp->crl);
    }
  }

#if defined(__clang__) && __clang_major__ >= 16
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wcast-function-type-strict"
#endif
  sk_X509_INFO_pop_free(inf, X509_INFO_free);
#if defined(__clang__) && __clang_major__ >= 16
#pragma clang diagnostic pop
#endif

  result = CURLE_OK;

out:

  if(cbio)
    BIO_free(cbio);

  return result;
}

int main(void)
{
  CURL *curl;

  CURLcode result = curl_global_init(CURL_GLOBAL_ALL);
  if(result != CURLE_OK)
    return (int)result;

  curl = curl_easy_init();
  if(curl) {
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(curl, CURLOPT_HEADER, 0L);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, stdout);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_cb);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, stderr);
    curl_easy_setopt(curl, CURLOPT_SSLCERTTYPE, "PEM");
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_URL, "https://www.example.com/");

    /* Turn off the default CA locations, otherwise libcurl loads CA
     * certificates from the locations that were detected/specified at
     * build-time
     */
    curl_easy_setopt(curl, CURLOPT_CAINFO, NULL);
    curl_easy_setopt(curl, CURLOPT_CAPATH, NULL);

    /* first try: retrieve page without CA certificates -> should fail
     * unless libcurl was built --with-ca-fallback enabled at build-time
     */
    result = curl_easy_perform(curl);
    if(result == CURLE_OK)
      printf("*** transfer succeeded ***\n");
    else
      printf("*** transfer failed ***\n");

    /* use a fresh connection (optional) this option seriously impacts
     * performance of multiple transfers but it is necessary order to
     * demonstrate this example. recall that the SSL ctx callback is only
     * called _before_ an SSL connection is established, therefore it does not
     * affect existing verified SSL connections already in the connection
     * cache associated with this handle. normally you would set the SSL ctx
     * function before making any transfers, and not use this option.
     */
    curl_easy_setopt(curl, CURLOPT_FRESH_CONNECT, 1L);

    /* second try: retrieve page using cacerts' certificate -> succeeds to
     * load the certificate by installing a function doing the necessary
     * "modifications" to the SSL CONTEXT before link init
     */
    curl_easy_setopt(curl, CURLOPT_SSL_CTX_FUNCTION, sslctx_function);
    result = curl_easy_perform(curl);
    if(result == CURLE_OK)
      printf("*** transfer succeeded ***\n");
    else
      printf("*** transfer failed ***\n");

    curl_easy_cleanup(curl);
  }
  curl_global_cleanup();
  return (int)result;
}
