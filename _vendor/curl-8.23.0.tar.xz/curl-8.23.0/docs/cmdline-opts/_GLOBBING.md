<!-- Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al. -->
<!-- SPDX-License-Identifier: curl -->
# GLOBBING
You can specify multiple URLs or parts of URLs by writing lists within braces
or ranges within brackets. We call this "globbing".

Provide a list with three different names like this:

    https://fun.example/{one,two,three}.jpg

    sftp://{one,two,three}.example/README

Do sequences of alphanumeric series by using [] as in:

    ftp://ftp.example.com/file[1-100].txt

With leading zeroes:

    ftp://ftp.example.com/file[001-100].txt

With letters through the alphabet:

    ftp://ftp.example.com/file[a-z].txt

Nested sequences are not supported, but you can use several ones next to each
other:

    https://example.com/archive[1996-1999]/vol[1-4]/part{a,b,c}.html

You can specify a step counter for the ranges to get every Nth number or
letter:

    https://example.com/file[1-100:10].txt

    https://example.com/file[a-z:2].txt

When using [] or {} sequences when invoked from a command line prompt, you
probably have to put the full URL within double quotes to avoid the shell from
interfering with it. This also goes for other characters treated special, like
for example '&', '?' and '*'.

The separate globbing components can be referenced in the --output option to
allow pieces to be reused in the target filename.

Starting in curl 8.21.0, the separate globbing parts can be named and
referenced by their names. The case sensitive alphanumeric name is set
enclosed within angle brackets after the opening character. Examples:

    https://fun.example/{<number>one,two,three}.jpg

    ftp://ftp.example.com/file[<range>1-100].txt

Setting the same glob name twice is an error.

Switch off globbing with --globoff.
