# ArkForgeApp（DevEco 工程）

这是 `reference_2` 中可直接由 DevEco Studio 打开的 ArkForge 工程，支持 `phone` 和 `tablet`，并包含 ARM64 QuickJS NAPI 模块。

1. 在 DevEco Studio 打开本目录。
2. 等待 OHPM 同步完成。
3. 打开 **File → Project Structure → Signing Configs**，为 `default` 启用 **Automatically generate signature**，并将 `default` 产品关联该签名。
4. 选择已连接的平板或手机，点击 **Run**。DevEco 会申请或刷新包含该设备的调试 Profile。

签名材料由 DevEco 管理；本工程没有提交私钥、证书或 Profile。

在 WEB-W00 真机上已验证 `harmony_demo` 的离线增量构建：在 App 编辑器修改 ArkTS，从“构建 → 本机离线构建并安装 HarmonyOS 工程”完成官方 ArkUI 转换、ARM64 方舟动态编译、HAP 打包、签名和本机安装。重开 ArkForge 后，通过“调试”启动已安装原生页面，页面按钮可返回工程；调试菜单可读取应用运行日志。

验证时关闭平板 Wi-Fi，并在触发构建后停止电脑 HDC 服务；修改按钮逻辑后分别得到 +3 和 +7 的真实原生交互。此路径不调用电脑编译服务。资源缓存不含预编译 ABC，资源、AppScope 和模块配置会先逐文件核对 SHA-256；发生变更会拒绝继续构建。当前不支持资源变更后的全量构建、任意模块名工程或 C/C++ 源码构建。

构建工具：`scripts/bundle_ui_transform.cjs` 从已安装 SDK 打包 UI 转换器，`scripts/stage_dynamic_toolchain.py` 暂存 ARM64 编译库和资源缓存，`scripts/package_workspace.py` 生成可编辑的真实工程 ZIP。签名材料仅需一次性导入设备，口令保存在系统 Asset Store。端内构建日志逐行显示并保存，编译失败保留诊断和红色失败结果。
