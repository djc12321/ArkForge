# 复用代码

- `entry/src/main/ets/components/workspace/`：来自 `djc12321/multism_lab` 的 WorkspaceShell、GlobalMenuBar、BottomDock、ResizablePane 和 WorkspaceVisualPolicy。仅复用前端容器、尺寸规则和拖动逻辑，不包含电路模拟器或仪器工具栏。MIT 许可全文见 `licenses/multism_lab-MIT.txt`。
- SyntaxHighlightService、ThemeService、FileTypeBadge、AppInputDialog：来自 KeloYuan/xxCode，已为 ArkForge 调整。MIT 许可全文见 `licenses/xxCode-MIT.txt`。
- QuickJS：许可见 `native/quickjs/LICENSE`。
- ArkTS-Dyn 编译器：OpenHarmony `arkcompiler_ets_frontend` 与 `arkcompiler_runtime_core`，Apache-2.0；由源码交叉编译为 OHOS ARM64，在 App 进程内调用。
- UI 转换器及组件配置：取自本机 DevEco SDK 6.1.0/API 23 的 ets-loader、其 TypeScript 版本与依赖；保留上游代码中的许可声明，相关材料适用各自原始许可和 SDK 条款。Node 桌面构建接口由本工程的虚拟文件系统适配，编译时不调用桌面进程。
