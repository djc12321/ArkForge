var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// workbench/extension/projectRun.js
var require_projectRun = __commonJS({
  "workbench/extension/projectRun.js"(exports2) {
    var vscode2 = require("vscode");
    exports2.registerProjectRun = function(context, native, output, setProgress) {
      let busy = false;
      const status = vscode2.window.createStatusBarItem(vscode2.StatusBarAlignment.Right, 100);
      status.text = "$(play) \u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B";
      status.tooltip = "\u5728\u5E73\u677F\u7F16\u8BD1\u5F53\u524D HarmonyOS \u5DE5\u7A0B\uFF0C\u6210\u529F\u540E\u786E\u8BA4\u5B89\u88C5";
      status.command = "arkforge.run";
      status.show();
      context.subscriptions.push(status);
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.run", async () => {
        if (busy) {
          vscode2.window.showInformationMessage("\u5F53\u524D\u5DE5\u7A0B\u6B63\u5728\u6784\u5EFA\u6216\u7B49\u5F85\u5B89\u88C5\u786E\u8BA4\uFF0C\u8BF7\u5148\u5B8C\u6210\u5F53\u524D\u64CD\u4F5C\u3002");
          return;
        }
        busy = true;
        status.text = "$(sync~spin) \u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B";
        const checked = (result) => {
          if (!result.includes("BUILD SUCCESSFUL") || result.includes("BUILD FAILED")) {
            const lines = result.split("\n"), index = lines.findIndex((line) => /ArkTS:ERROR/.test(line));
            const end = lines.findIndex((line, i) => i > index && /ArkTS:(ERROR|WARN)|BUILD FAILED|> ArkForge|^Error:/.test(line));
            throw new Error(index >= 0 ? lines.slice(index, end >= 0 ? end : void 0).join("\n") : lines.filter((line) => /error (SDK|TS)|Error:|失败|缺少/.test(line)).slice(-3).join("\n") || "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u67E5\u770B\u6784\u5EFA\u8F93\u51FA");
          }
          return result;
        };
        const task = async (title, method, args = {}) => vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title, cancellable: false }, async (progress) => {
          setProgress(progress);
          try {
            return checked(await native(method, args));
          } finally {
            setProgress(void 0);
          }
        });
        try {
          if (!await vscode2.commands.executeCommand("arkforge.ensureSigning")) return;
          if (!await vscode2.workspace.saveAll(false)) throw new Error("\u8BF7\u5B8C\u6210\u6587\u4EF6\u4FDD\u5B58\u540E\u91CD\u65B0\u6784\u5EFA");
          output.show(true);
          const built = await task("ArkForge\uFF1A\u6B63\u5728\u672C\u673A\u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B", "compile_project");
          const id = built.match(/> Prepared build: (\d+)/)?.[1];
          if (!id) throw new Error("\u8BF7\u67E5\u770B\u6784\u5EFA\u8F93\u51FA\uFF0C\u786E\u8BA4 HAP \u4EA7\u7269\u53CA\u6784\u5EFA\u8BB0\u5F55");
          status.text = "$(play) \u7B49\u5F85\u5B89\u88C5\u786E\u8BA4";
          const choice = await vscode2.window.showInformationMessage("\u5F53\u524D\u5DE5\u7A0B\u7F16\u8BD1\u6210\u529F\uFF0C\u662F\u5426\u5B89\u88C5\u5230\u6B64\u8BBE\u5907\uFF1F", {
            modal: true,
            detail: "\u5DF2\u5728\u5E73\u677F\u5B8C\u6210 SDK \u68C0\u67E5\u3001\u7F16\u8BD1\u3001HAP \u6253\u5305\u3001\u7B7E\u540D\u53CA\u9A8C\u7B7E\u3002\u5B89\u88C5\u4F1A\u66F4\u65B0\u6B64\u5DE5\u7A0B\u5BF9\u5E94\u7684\u5E94\u7528\uFF1B\u53D6\u6D88\u540E\u4FDD\u7559\u5DF2\u7F16\u8BD1\u4EA7\u7269\u3002"
          }, "\u5B89\u88C5\u5E76\u8FD0\u884C", "\u4EC5\u5B89\u88C5");
          if (!choice) {
            output.info("\u7528\u6237\u53D6\u6D88\u5B89\u88C5\uFF1B\u7F16\u8BD1\u4EA7\u7269\u5DF2\u4FDD\u7559\uFF0C\u8BBE\u5907\u5E94\u7528\u672A\u66F4\u65B0\u3002");
            return;
          }
          status.text = "$(sync~spin) \u6B63\u5728\u5B89\u88C5";
          const installed = await task("ArkForge\uFF1A\u6B63\u5728\u5B89\u88C5\u5DF2\u7F16\u8BD1\u7684 HAP", "install_prepared", { path: id });
          if (choice === "\u5B89\u88C5\u5E76\u8FD0\u884C") await native("run_app");
          else vscode2.window.showInformationMessage("\u5F53\u524D\u5DE5\u7A0B\u5DF2\u5B89\u88C5\u6210\u529F\u3002", "\u8FD0\u884C\u5E94\u7528").then((value) => {
            if (value === "\u8FD0\u884C\u5E94\u7528") vscode2.commands.executeCommand("arkforge.launch");
          });
          return installed;
        } catch (error) {
          output.error(error.message);
          vscode2.window.showErrorMessage(error.message, "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA", "\u67E5\u770B\u95EE\u9898").then(async (choice) => {
            if (choice === "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA") output.show(true);
            if (choice === "\u67E5\u770B\u95EE\u9898") await vscode2.commands.executeCommand("workbench.actions.view.problems");
          }).catch(() => {
          });
        } finally {
          busy = false;
          status.text = "$(play) \u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B";
        }
      }));
    };
  }
});

// ../../../_vendor/vscode/node_modules/concat-map/index.js
var require_concat_map = __commonJS({
  "../../../_vendor/vscode/node_modules/concat-map/index.js"(exports2, module2) {
    module2.exports = function(xs, fn) {
      var res = [];
      for (var i = 0; i < xs.length; i++) {
        var x = fn(xs[i], i);
        if (isArray(x)) res.push.apply(res, x);
        else res.push(x);
      }
      return res;
    };
    var isArray = Array.isArray || function(xs) {
      return Object.prototype.toString.call(xs) === "[object Array]";
    };
  }
});

// ../../../_vendor/vscode/node_modules/balanced-match/index.js
var require_balanced_match = __commonJS({
  "../../../_vendor/vscode/node_modules/balanced-match/index.js"(exports2, module2) {
    "use strict";
    module2.exports = balanced;
    function balanced(a, b, str) {
      if (a instanceof RegExp) a = maybeMatch(a, str);
      if (b instanceof RegExp) b = maybeMatch(b, str);
      var r = range(a, b, str);
      return r && {
        start: r[0],
        end: r[1],
        pre: str.slice(0, r[0]),
        body: str.slice(r[0] + a.length, r[1]),
        post: str.slice(r[1] + b.length)
      };
    }
    function maybeMatch(reg, str) {
      var m = str.match(reg);
      return m ? m[0] : null;
    }
    balanced.range = range;
    function range(a, b, str) {
      var begs, beg, left, right, result;
      var ai = str.indexOf(a);
      var bi = str.indexOf(b, ai + 1);
      var i = ai;
      if (ai >= 0 && bi > 0) {
        if (a === b) {
          return [ai, bi];
        }
        begs = [];
        left = str.length;
        while (i >= 0 && !result) {
          if (i == ai) {
            begs.push(i);
            ai = str.indexOf(a, i + 1);
          } else if (begs.length == 1) {
            result = [begs.pop(), bi];
          } else {
            beg = begs.pop();
            if (beg < left) {
              left = beg;
              right = bi;
            }
            bi = str.indexOf(b, i + 1);
          }
          i = ai < bi && ai >= 0 ? ai : bi;
        }
        if (begs.length) {
          result = [left, right];
        }
      }
      return result;
    }
  }
});

// ../../../_vendor/vscode/node_modules/brace-expansion/index.js
var require_brace_expansion = __commonJS({
  "../../../_vendor/vscode/node_modules/brace-expansion/index.js"(exports2, module2) {
    var concatMap = require_concat_map();
    var balanced = require_balanced_match();
    module2.exports = expandTop;
    var escSlash = "\0SLASH" + Math.random() + "\0";
    var escOpen = "\0OPEN" + Math.random() + "\0";
    var escClose = "\0CLOSE" + Math.random() + "\0";
    var escComma = "\0COMMA" + Math.random() + "\0";
    var escPeriod = "\0PERIOD" + Math.random() + "\0";
    var EXPANSION_MAX = 1e5;
    var EXPANSION_MAX_LENGTH = 4e6;
    var EXPANSION_MAX_DEPTH = 1e3;
    var EXPANSION_MAX_REWRITES = 1e3;
    function numeric(str) {
      return parseInt(str, 10) == str ? parseInt(str, 10) : str.charCodeAt(0);
    }
    function escapeBraces(str) {
      return str.split("\\\\").join(escSlash).split("\\{").join(escOpen).split("\\}").join(escClose).split("\\,").join(escComma).split("\\.").join(escPeriod);
    }
    function unescapeBraces(str) {
      return str.split(escSlash).join("\\").split(escOpen).join("{").split(escClose).join("}").split(escComma).join(",").split(escPeriod).join(".");
    }
    function pushAll(target, items) {
      for (var i = 0; i < items.length; i++) {
        target.push(items[i]);
      }
    }
    function parseCommaParts(str) {
      var parts = [];
      var carry = "";
      for (; ; ) {
        var m = balanced("{", "}", str);
        if (!m) {
          var tail = str.split(",");
          tail[0] = carry + tail[0];
          pushAll(parts, tail);
          return parts;
        }
        var pre = m.pre;
        var body = m.body;
        var post = m.post;
        var p = pre.split(",");
        p[0] = carry + p[0];
        p[p.length - 1] += "{" + body + "}";
        if (!post.length) {
          pushAll(parts, p);
          return parts;
        }
        carry = p.pop();
        pushAll(parts, p);
        str = post;
      }
    }
    function expandTop(str, options) {
      if (!str)
        return [];
      options = options || {};
      var max = options.max == null ? EXPANSION_MAX : options.max;
      var maxLength = options.maxLength == null ? EXPANSION_MAX_LENGTH : options.maxLength;
      var maxDepth = options.maxDepth == null ? EXPANSION_MAX_DEPTH : options.maxDepth;
      var maxRewrites = options.maxRewrites == null ? EXPANSION_MAX_REWRITES : options.maxRewrites;
      if (str.substr(0, 2) === "{}") {
        str = "\\{\\}" + str.substr(2);
      }
      return expand(escapeBraces(str), max, maxLength, maxDepth, 0, maxRewrites, true).map(unescapeBraces);
    }
    function embrace(str) {
      return "{" + str + "}";
    }
    function isPadded(el) {
      return /^-?0\d/.test(el);
    }
    function lte(i, y) {
      return i <= y;
    }
    function gte(i, y) {
      return i >= y;
    }
    function combine(acc, base, pre, values, max, maxLength, dropEmpties, outBase) {
      var out = [];
      var length = 0;
      for (var a = 0; a < acc.length; a++) {
        for (var v = 0; v < values.length; v++) {
          if (out.length >= max) return out;
          var expansion = acc[a] + pre + values[v];
          if (dropEmpties && expansion.length === base[a]) continue;
          if (length + expansion.length > maxLength) return out;
          out.push(expansion);
          outBase.push(base[a]);
          length += expansion.length;
        }
      }
      return out;
    }
    function expandSequence(body, isAlphaSequence, max, maxLength) {
      var n = body.split(/\.\./);
      var N = [];
      if (n[0] === void 0 || n[1] === void 0) {
        return N;
      }
      var x = numeric(n[0]);
      var y = numeric(n[1]);
      var width = Math.max(n[0].length, n[1].length);
      var incr = n.length === 3 && n[2] !== void 0 ? Math.max(Math.abs(numeric(n[2])), 1) : 1;
      var test = lte;
      var reverse = y < x;
      if (reverse) {
        incr *= -1;
        test = gte;
      }
      var pad = n.some(isPadded);
      var length = 0;
      for (var i = x; test(i, y) && N.length < max; i += incr) {
        var c;
        if (isAlphaSequence) {
          c = String.fromCharCode(i);
          if (c === "\\") {
            c = "";
          }
        } else {
          c = String(i);
          if (pad) {
            var need = width - c.length;
            if (need > 0) {
              var z = new Array(need + 1).join("0");
              if (i < 0) {
                c = "-" + z + c.slice(1);
              } else {
                c = z + c;
              }
            }
          }
        }
        if (length + c.length > maxLength) break;
        N.push(c);
        length += c.length;
      }
      return N;
    }
    function expand(str, max, maxLength, maxDepth, depth, maxRewrites, isTop) {
      if (depth > maxDepth) {
        return [str];
      }
      var acc = [""];
      var accBase = [0];
      var rewrites = 0;
      var dropEmpties = false;
      var firstGroup = true;
      var nextBase;
      for (; ; ) {
        var m = balanced("{", "}", str);
        if (!m) {
          return combine(acc, accBase, str, [""], max, maxLength, dropEmpties, []);
        }
        var pre = m.pre;
        if (/\$$/.test(pre)) {
          return combine(acc, accBase, str, [""], max, maxLength, dropEmpties, []);
        }
        var isNumericSequence = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(m.body);
        var isAlphaSequence = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(m.body);
        var isSequence = isNumericSequence || isAlphaSequence;
        var isOptions = m.body.indexOf(",") >= 0;
        if (!isSequence && !isOptions) {
          if (rewrites < maxRewrites && m.post.match(/,(?!,).*\}/)) {
            rewrites++;
            str = m.pre + "{" + m.body + escClose + m.post;
            isTop = true;
            firstGroup = true;
            dropEmpties = false;
            accBase = [];
            for (var b = 0; b < acc.length; b++) {
              accBase.push(acc[b].length);
            }
            continue;
          }
          return combine(
            acc,
            accBase,
            pre + "{" + m.body + "}" + m.post,
            [""],
            max,
            maxLength,
            dropEmpties,
            []
          );
        }
        if (firstGroup) {
          dropEmpties = isTop && !isSequence;
          firstGroup = false;
        }
        var values;
        if (isSequence) {
          values = expandSequence(m.body, isAlphaSequence, max, maxLength);
        } else {
          var n = parseCommaParts(m.body);
          if (n.length === 1 && n[0] !== void 0) {
            n = expand(n[0], max, maxLength, maxDepth, depth + 1, maxRewrites, false).map(embrace);
            if (n.length === 1) {
              nextBase = [];
              acc = combine(
                acc,
                accBase,
                pre + n[0],
                [""],
                max,
                maxLength,
                dropEmpties && !m.post.length,
                nextBase
              );
              accBase = nextBase;
              if (!m.post.length) break;
              str = m.post;
              continue;
            }
          }
          var dropsEmpties = dropEmpties && !m.post.length && !pre;
          for (var d = 0; dropsEmpties && d < acc.length; d++) {
            if (acc[d].length !== accBase[d]) {
              dropsEmpties = false;
            }
          }
          values = [];
          var valuesLength = 0;
          outer: for (var j = 0; j < n.length; j++) {
            var expanded = expand(n[j], max, maxLength, maxDepth, depth + 1, maxRewrites, false);
            for (var k = 0; k < expanded.length; k++) {
              var v = expanded[k];
              if (dropsEmpties && !v) continue;
              if (values.length >= max || valuesLength + v.length > maxLength) {
                break outer;
              }
              values.push(v);
              valuesLength += v.length;
            }
          }
        }
        nextBase = [];
        acc = combine(
          acc,
          accBase,
          pre,
          values,
          max,
          maxLength,
          dropEmpties && !m.post.length,
          nextBase
        );
        accBase = nextBase;
        if (!m.post.length) break;
        str = m.post;
      }
      return acc;
    }
  }
});

// ../../../_vendor/vscode/node_modules/minimatch/minimatch.js
var require_minimatch = __commonJS({
  "../../../_vendor/vscode/node_modules/minimatch/minimatch.js"(exports2, module2) {
    module2.exports = minimatch;
    minimatch.Minimatch = Minimatch;
    var path = (function() {
      try {
        return require("path");
      } catch (e) {
      }
    })() || {
      sep: "/"
    };
    minimatch.sep = path.sep;
    var GLOBSTAR = minimatch.GLOBSTAR = Minimatch.GLOBSTAR = {};
    var expand = require_brace_expansion();
    var plTypes = {
      "!": { open: "(?:(?!(?:", close: "))[^/]*?)" },
      "?": { open: "(?:", close: ")?" },
      "+": { open: "(?:", close: ")+" },
      "*": { open: "(?:", close: ")*" },
      "@": { open: "(?:", close: ")" }
    };
    var qmark = "[^/]";
    var star = qmark + "*?";
    var twoStarDot = "(?:(?!(?:\\/|^)(?:\\.{1,2})($|\\/)).)*?";
    var twoStarNoDot = "(?:(?!(?:\\/|^)\\.).)*?";
    var reSpecials = charSet("().*{}+?[]^$\\!");
    function charSet(s) {
      return s.split("").reduce(function(set, c) {
        set[c] = true;
        return set;
      }, {});
    }
    var slashSplit = /\/+/;
    minimatch.filter = filter;
    function filter(pattern, options) {
      options = options || {};
      return function(p, i, list) {
        return minimatch(p, pattern, options);
      };
    }
    function ext(a, b) {
      b = b || {};
      var t = {};
      Object.keys(a).forEach(function(k) {
        t[k] = a[k];
      });
      Object.keys(b).forEach(function(k) {
        t[k] = b[k];
      });
      return t;
    }
    minimatch.defaults = function(def) {
      if (!def || typeof def !== "object" || !Object.keys(def).length) {
        return minimatch;
      }
      var orig = minimatch;
      var m = function minimatch2(p, pattern, options) {
        return orig(p, pattern, ext(def, options));
      };
      m.Minimatch = function Minimatch2(pattern, options) {
        return new orig.Minimatch(pattern, ext(def, options));
      };
      m.Minimatch.defaults = function defaults(options) {
        return orig.defaults(ext(def, options)).Minimatch;
      };
      m.filter = function filter2(pattern, options) {
        return orig.filter(pattern, ext(def, options));
      };
      m.defaults = function defaults(options) {
        return orig.defaults(ext(def, options));
      };
      m.makeRe = function makeRe2(pattern, options) {
        return orig.makeRe(pattern, ext(def, options));
      };
      m.braceExpand = function braceExpand2(pattern, options) {
        return orig.braceExpand(pattern, ext(def, options));
      };
      m.match = function(list, pattern, options) {
        return orig.match(list, pattern, ext(def, options));
      };
      return m;
    };
    Minimatch.defaults = function(def) {
      return minimatch.defaults(def).Minimatch;
    };
    function minimatch(p, pattern, options) {
      assertValidPattern(pattern);
      if (!options) options = {};
      if (!options.nocomment && pattern.charAt(0) === "#") {
        return false;
      }
      return new Minimatch(pattern, options).match(p);
    }
    function Minimatch(pattern, options) {
      if (!(this instanceof Minimatch)) {
        return new Minimatch(pattern, options);
      }
      assertValidPattern(pattern);
      if (!options) options = {};
      pattern = pattern.trim();
      if (!options.allowWindowsEscape && path.sep !== "/") {
        pattern = pattern.split(path.sep).join("/");
      }
      this.options = options;
      this.maxGlobstarRecursion = options.maxGlobstarRecursion !== void 0 ? options.maxGlobstarRecursion : 200;
      this.set = [];
      this.pattern = pattern;
      this.regexp = null;
      this.negate = false;
      this.comment = false;
      this.empty = false;
      this.partial = !!options.partial;
      this.make();
    }
    Minimatch.prototype.debug = function() {
    };
    Minimatch.prototype.make = make;
    function make() {
      var pattern = this.pattern;
      var options = this.options;
      if (!options.nocomment && pattern.charAt(0) === "#") {
        this.comment = true;
        return;
      }
      if (!pattern) {
        this.empty = true;
        return;
      }
      this.parseNegate();
      var set = this.globSet = this.braceExpand();
      if (options.debug) this.debug = function debug() {
        console.error.apply(console, arguments);
      };
      this.debug(this.pattern, set);
      set = this.globParts = set.map(function(s) {
        return s.split(slashSplit);
      });
      this.debug(this.pattern, set);
      set = set.map(function(s, si, set2) {
        return s.map(this.parse, this);
      }, this);
      this.debug(this.pattern, set);
      set = set.filter(function(s) {
        return s.indexOf(false) === -1;
      });
      this.debug(this.pattern, set);
      this.set = set;
    }
    Minimatch.prototype.parseNegate = parseNegate;
    function parseNegate() {
      var pattern = this.pattern;
      var negate = false;
      var options = this.options;
      var negateOffset = 0;
      if (options.nonegate) return;
      for (var i = 0, l = pattern.length; i < l && pattern.charAt(i) === "!"; i++) {
        negate = !negate;
        negateOffset++;
      }
      if (negateOffset) this.pattern = pattern.substr(negateOffset);
      this.negate = negate;
    }
    minimatch.braceExpand = function(pattern, options) {
      return braceExpand(pattern, options);
    };
    Minimatch.prototype.braceExpand = braceExpand;
    function braceExpand(pattern, options) {
      if (!options) {
        if (this instanceof Minimatch) {
          options = this.options;
        } else {
          options = {};
        }
      }
      pattern = typeof pattern === "undefined" ? this.pattern : pattern;
      assertValidPattern(pattern);
      if (options.nobrace || !/\{(?:(?!\{).)*\}/.test(pattern)) {
        return [pattern];
      }
      return expand(pattern);
    }
    var MAX_PATTERN_LENGTH = 1024 * 64;
    var assertValidPattern = function(pattern) {
      if (typeof pattern !== "string") {
        throw new TypeError("invalid pattern");
      }
      if (pattern.length > MAX_PATTERN_LENGTH) {
        throw new TypeError("pattern is too long");
      }
    };
    Minimatch.prototype.parse = parse;
    var SUBPARSE = {};
    function parse(pattern, isSub) {
      assertValidPattern(pattern);
      var options = this.options;
      if (pattern === "**") {
        if (!options.noglobstar)
          return GLOBSTAR;
        else
          pattern = "*";
      }
      if (pattern === "") return "";
      var re = "";
      var hasMagic = !!options.nocase;
      var escaping = false;
      var patternListStack = [];
      var negativeLists = [];
      var stateChar;
      var inClass = false;
      var reClassStart = -1;
      var classStart = -1;
      var patternStart = pattern.charAt(0) === "." ? "" : options.dot ? "(?!(?:^|\\/)\\.{1,2}(?:$|\\/))" : "(?!\\.)";
      var self = this;
      function clearStateChar() {
        if (stateChar) {
          switch (stateChar) {
            case "*":
              re += star;
              hasMagic = true;
              break;
            case "?":
              re += qmark;
              hasMagic = true;
              break;
            default:
              re += "\\" + stateChar;
              break;
          }
          self.debug("clearStateChar %j %j", stateChar, re);
          stateChar = false;
        }
      }
      for (var i = 0, len = pattern.length, c; i < len && (c = pattern.charAt(i)); i++) {
        this.debug("%s	%s %s %j", pattern, i, re, c);
        if (escaping && reSpecials[c]) {
          re += "\\" + c;
          escaping = false;
          continue;
        }
        switch (c) {
          /* istanbul ignore next */
          case "/": {
            return false;
          }
          case "\\":
            clearStateChar();
            escaping = true;
            continue;
          // the various stateChar values
          // for the "extglob" stuff.
          case "?":
          case "*":
          case "+":
          case "@":
          case "!":
            this.debug("%s	%s %s %j <-- stateChar", pattern, i, re, c);
            if (inClass) {
              this.debug("  in class");
              if (c === "!" && i === classStart + 1) c = "^";
              re += c;
              continue;
            }
            if (c === "*" && stateChar === "*") continue;
            self.debug("call clearStateChar %j", stateChar);
            clearStateChar();
            stateChar = c;
            if (options.noext) clearStateChar();
            continue;
          case "(":
            if (inClass) {
              re += "(";
              continue;
            }
            if (!stateChar) {
              re += "\\(";
              continue;
            }
            patternListStack.push({
              type: stateChar,
              start: i - 1,
              reStart: re.length,
              open: plTypes[stateChar].open,
              close: plTypes[stateChar].close
            });
            re += stateChar === "!" ? "(?:(?!(?:" : "(?:";
            this.debug("plType %j %j", stateChar, re);
            stateChar = false;
            continue;
          case ")":
            if (inClass || !patternListStack.length) {
              re += "\\)";
              continue;
            }
            clearStateChar();
            hasMagic = true;
            var pl = patternListStack.pop();
            re += pl.close;
            if (pl.type === "!") {
              negativeLists.push(pl);
            }
            pl.reEnd = re.length;
            continue;
          case "|":
            if (inClass || !patternListStack.length || escaping) {
              re += "\\|";
              escaping = false;
              continue;
            }
            clearStateChar();
            re += "|";
            continue;
          // these are mostly the same in regexp and glob
          case "[":
            clearStateChar();
            if (inClass) {
              re += "\\" + c;
              continue;
            }
            inClass = true;
            classStart = i;
            reClassStart = re.length;
            re += c;
            continue;
          case "]":
            if (i === classStart + 1 || !inClass) {
              re += "\\" + c;
              escaping = false;
              continue;
            }
            var cs = pattern.substring(classStart + 1, i);
            try {
              RegExp("[" + cs + "]");
            } catch (er) {
              var sp = this.parse(cs, SUBPARSE);
              re = re.substr(0, reClassStart) + "\\[" + sp[0] + "\\]";
              hasMagic = hasMagic || sp[1];
              inClass = false;
              continue;
            }
            hasMagic = true;
            inClass = false;
            re += c;
            continue;
          default:
            clearStateChar();
            if (escaping) {
              escaping = false;
            } else if (reSpecials[c] && !(c === "^" && inClass)) {
              re += "\\";
            }
            re += c;
        }
      }
      if (inClass) {
        cs = pattern.substr(classStart + 1);
        sp = this.parse(cs, SUBPARSE);
        re = re.substr(0, reClassStart) + "\\[" + sp[0];
        hasMagic = hasMagic || sp[1];
      }
      for (pl = patternListStack.pop(); pl; pl = patternListStack.pop()) {
        var tail = re.slice(pl.reStart + pl.open.length);
        this.debug("setting tail", re, pl);
        tail = tail.replace(/((?:\\{2}){0,64})(\\?)\|/g, function(_, $1, $2) {
          if (!$2) {
            $2 = "\\";
          }
          return $1 + $1 + $2 + "|";
        });
        this.debug("tail=%j\n   %s", tail, tail, pl, re);
        var t = pl.type === "*" ? star : pl.type === "?" ? qmark : "\\" + pl.type;
        hasMagic = true;
        re = re.slice(0, pl.reStart) + t + "\\(" + tail;
      }
      clearStateChar();
      if (escaping) {
        re += "\\\\";
      }
      var addPatternStart = false;
      switch (re.charAt(0)) {
        case "[":
        case ".":
        case "(":
          addPatternStart = true;
      }
      for (var n = negativeLists.length - 1; n > -1; n--) {
        var nl = negativeLists[n];
        var nlBefore = re.slice(0, nl.reStart);
        var nlFirst = re.slice(nl.reStart, nl.reEnd - 8);
        var nlLast = re.slice(nl.reEnd - 8, nl.reEnd);
        var nlAfter = re.slice(nl.reEnd);
        nlLast += nlAfter;
        var openParensBefore = nlBefore.split("(").length - 1;
        var cleanAfter = nlAfter;
        for (i = 0; i < openParensBefore; i++) {
          cleanAfter = cleanAfter.replace(/\)[+*?]?/, "");
        }
        nlAfter = cleanAfter;
        var dollar = "";
        if (nlAfter === "" && isSub !== SUBPARSE) {
          dollar = "$";
        }
        var newRe = nlBefore + nlFirst + nlAfter + dollar + nlLast;
        re = newRe;
      }
      if (re !== "" && hasMagic) {
        re = "(?=.)" + re;
      }
      if (addPatternStart) {
        re = patternStart + re;
      }
      if (isSub === SUBPARSE) {
        return [re, hasMagic];
      }
      if (!hasMagic) {
        return globUnescape(pattern);
      }
      var flags = options.nocase ? "i" : "";
      try {
        var regExp = new RegExp("^" + re + "$", flags);
      } catch (er) {
        return new RegExp("$.");
      }
      regExp._glob = pattern;
      regExp._src = re;
      return regExp;
    }
    minimatch.makeRe = function(pattern, options) {
      return new Minimatch(pattern, options || {}).makeRe();
    };
    Minimatch.prototype.makeRe = makeRe;
    function makeRe() {
      if (this.regexp || this.regexp === false) return this.regexp;
      var set = this.set;
      if (!set.length) {
        this.regexp = false;
        return this.regexp;
      }
      var options = this.options;
      var twoStar = options.noglobstar ? star : options.dot ? twoStarDot : twoStarNoDot;
      var flags = options.nocase ? "i" : "";
      var re = set.map(function(pattern) {
        return pattern.map(function(p) {
          return p === GLOBSTAR ? twoStar : typeof p === "string" ? regExpEscape(p) : p._src;
        }).join("\\/");
      }).join("|");
      re = "^(?:" + re + ")$";
      if (this.negate) re = "^(?!" + re + ").*$";
      try {
        this.regexp = new RegExp(re, flags);
      } catch (ex) {
        this.regexp = false;
      }
      return this.regexp;
    }
    minimatch.match = function(list, pattern, options) {
      options = options || {};
      var mm = new Minimatch(pattern, options);
      list = list.filter(function(f) {
        return mm.match(f);
      });
      if (mm.options.nonull && !list.length) {
        list.push(pattern);
      }
      return list;
    };
    Minimatch.prototype.match = function match(f, partial) {
      if (typeof partial === "undefined") partial = this.partial;
      this.debug("match", f, this.pattern);
      if (this.comment) return false;
      if (this.empty) return f === "";
      if (f === "/" && partial) return true;
      var options = this.options;
      if (path.sep !== "/") {
        f = f.split(path.sep).join("/");
      }
      f = f.split(slashSplit);
      this.debug(this.pattern, "split", f);
      var set = this.set;
      this.debug(this.pattern, "set", set);
      var filename;
      var i;
      for (i = f.length - 1; i >= 0; i--) {
        filename = f[i];
        if (filename) break;
      }
      for (i = 0; i < set.length; i++) {
        var pattern = set[i];
        var file = f;
        if (options.matchBase && pattern.length === 1) {
          file = [filename];
        }
        var hit = this.matchOne(file, pattern, partial);
        if (hit) {
          if (options.flipNegate) return true;
          return !this.negate;
        }
      }
      if (options.flipNegate) return false;
      return this.negate;
    };
    Minimatch.prototype.matchOne = function(file, pattern, partial) {
      if (pattern.indexOf(GLOBSTAR) !== -1) {
        return this._matchGlobstar(file, pattern, partial, 0, 0);
      }
      return this._matchOne(file, pattern, partial, 0, 0);
    };
    Minimatch.prototype._matchGlobstar = function(file, pattern, partial, fileIndex, patternIndex) {
      var i;
      var firstgs = -1;
      for (i = patternIndex; i < pattern.length; i++) {
        if (pattern[i] === GLOBSTAR) {
          firstgs = i;
          break;
        }
      }
      var lastgs = -1;
      for (i = pattern.length - 1; i >= 0; i--) {
        if (pattern[i] === GLOBSTAR) {
          lastgs = i;
          break;
        }
      }
      var head = pattern.slice(patternIndex, firstgs);
      var body = partial ? pattern.slice(firstgs + 1) : pattern.slice(firstgs + 1, lastgs);
      var tail = partial ? [] : pattern.slice(lastgs + 1);
      if (head.length) {
        var fileHead = file.slice(fileIndex, fileIndex + head.length);
        if (!this._matchOne(fileHead, head, partial, 0, 0)) {
          return false;
        }
        fileIndex += head.length;
      }
      var fileTailMatch = 0;
      if (tail.length) {
        if (tail.length + fileIndex > file.length) return false;
        var tailStart = file.length - tail.length;
        if (this._matchOne(file, tail, partial, tailStart, 0)) {
          fileTailMatch = tail.length;
        } else {
          if (file[file.length - 1] !== "" || fileIndex + tail.length === file.length) {
            return false;
          }
          tailStart--;
          if (!this._matchOne(file, tail, partial, tailStart, 0)) {
            return false;
          }
          fileTailMatch = tail.length + 1;
        }
      }
      if (!body.length) {
        var sawSome = !!fileTailMatch;
        for (i = fileIndex; i < file.length - fileTailMatch; i++) {
          var f = String(file[i]);
          sawSome = true;
          if (f === "." || f === ".." || !this.options.dot && f.charAt(0) === ".") {
            return false;
          }
        }
        return partial || sawSome;
      }
      var bodySegments = [[[], 0]];
      var currentBody = bodySegments[0];
      var nonGsParts = 0;
      var nonGsPartsSums = [0];
      for (var bi = 0; bi < body.length; bi++) {
        var b = body[bi];
        if (b === GLOBSTAR) {
          nonGsPartsSums.push(nonGsParts);
          currentBody = [[], 0];
          bodySegments.push(currentBody);
        } else {
          currentBody[0].push(b);
          nonGsParts++;
        }
      }
      var idx = bodySegments.length - 1;
      var fileLength = file.length - fileTailMatch;
      for (var si = 0; si < bodySegments.length; si++) {
        bodySegments[si][1] = fileLength - (nonGsPartsSums[idx--] + bodySegments[si][0].length);
      }
      return !!this._matchGlobStarBodySections(
        file,
        bodySegments,
        fileIndex,
        0,
        partial,
        0,
        !!fileTailMatch
      );
    };
    Minimatch.prototype._matchGlobStarBodySections = function(file, bodySegments, fileIndex, bodyIndex, partial, globStarDepth, sawTail) {
      var bs = bodySegments[bodyIndex];
      if (!bs) {
        for (var i = fileIndex; i < file.length; i++) {
          sawTail = true;
          var f = file[i];
          if (f === "." || f === ".." || !this.options.dot && f.charAt(0) === ".") {
            return false;
          }
        }
        return sawTail;
      }
      var body = bs[0];
      var after = bs[1];
      while (fileIndex <= after) {
        var m = this._matchOne(
          file.slice(0, fileIndex + body.length),
          body,
          partial,
          fileIndex,
          0
        );
        if (m && globStarDepth < this.maxGlobstarRecursion) {
          var sub = this._matchGlobStarBodySections(
            file,
            bodySegments,
            fileIndex + body.length,
            bodyIndex + 1,
            partial,
            globStarDepth + 1,
            sawTail
          );
          if (sub !== false) {
            return sub;
          }
        }
        var f = file[fileIndex];
        if (f === "." || f === ".." || !this.options.dot && f.charAt(0) === ".") {
          return false;
        }
        fileIndex++;
      }
      return partial || null;
    };
    Minimatch.prototype._matchOne = function(file, pattern, partial, fileIndex, patternIndex) {
      var fi, pi, fl, pl;
      for (fi = fileIndex, pi = patternIndex, fl = file.length, pl = pattern.length; fi < fl && pi < pl; fi++, pi++) {
        this.debug("matchOne loop");
        var p = pattern[pi];
        var f = file[fi];
        this.debug(pattern, p, f);
        if (p === false || p === GLOBSTAR) return false;
        var hit;
        if (typeof p === "string") {
          hit = f === p;
          this.debug("string match", p, f, hit);
        } else {
          hit = f.match(p);
          this.debug("pattern match", p, f, hit);
        }
        if (!hit) return false;
      }
      if (fi === fl && pi === pl) {
        return true;
      } else if (fi === fl) {
        return partial;
      } else if (pi === pl) {
        return fi === fl - 1 && file[fi] === "";
      }
      throw new Error("wtf?");
    };
    function globUnescape(s) {
      return s.replace(/\\(.)/g, "$1");
    }
    function regExpEscape(s) {
      return s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    }
  }
});

// workbench/extension/projectSearch.js
var require_projectSearch = __commonJS({
  "workbench/extension/projectSearch.js"(exports2) {
    var vscode2 = require("vscode");
    var minimatch = require_minimatch();
    exports2.registerProjectSearch = function(context, native) {
      async function files(options, token) {
        const names = JSON.parse(await native("fs.index", { path: options.folder.path }));
        return names.filter((name) => !token.isCancellationRequested && (!(options.includes || []).length || options.includes.some((glob) => minimatch(name, glob, { dot: true }))) && !(options.excludes || []).some((glob) => minimatch(name, glob, { dot: true })));
      }
      context.subscriptions.push(vscode2.workspace.registerFileSearchProvider("arkforge", {
        provideFileSearchResults: async (query, options, token) => {
          const pattern = query.pattern.toLowerCase();
          const names = (await files(options, token)).filter((name) => {
            let index = 0;
            for (const c of name.toLowerCase()) if (c === pattern[index]) index++;
            return index === pattern.length;
          });
          return names.slice(0, options.maxResults ?? 2e4).map((name) => vscode2.Uri.joinPath(options.folder, name));
        }
      }));
      context.subscriptions.push(vscode2.workspace.registerTextSearchProvider("arkforge", {
        provideTextSearchResults: async (query, options, progress, token) => {
          if (!query.pattern) return { limitHit: false };
          const pattern = query.isRegExp ? query.pattern : query.pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const regex = new RegExp(pattern, "gm" + (query.isCaseSensitive ? "" : "i") + "u");
          let count = 0, unreadable = 0;
          const max = options.maxResults ?? 1e4;
          const names = (await files(options, token)).filter((name) => !/\.(png|jpe?g|gif|webp|so|zip|hap|abc|wasm|ttf|woff2?)$/i.test(name));
          async function* contents() {
            for (let offset = 0; offset < names.length && !token.isCancellationRequested; ) {
              const batch = JSON.parse(await native("fs.readBatch", { path: options.folder.path, files: names.slice(offset, offset + 128), maxFileSize: options.maxFileSize, pattern: regex.source, matchCase: query.isCaseSensitive }));
              if (!batch.consumed) throw new Error("\u8BF7\u7F29\u5C0F\u641C\u7D22\u8303\u56F4\u540E\u91CD\u8BD5");
              offset += batch.consumed;
              unreadable += batch.unreadable;
              for (const item of batch.items) yield item;
            }
          }
          for await (const { name, text } of contents()) {
            if (token.isCancellationRequested) break;
            const uri = vscode2.Uri.joinPath(options.folder, name);
            const starts = [0];
            for (let i = 0; i < text.length; i++) if (text[i] === "\n") starts.push(i + 1);
            const position = (offset) => {
              let lo = 0, hi = starts.length;
              while (lo + 1 < hi) {
                const mid = lo + hi >> 1;
                if (starts[mid] <= offset) lo = mid;
                else hi = mid;
              }
              return { line: lo, column: offset - starts[lo] };
            };
            regex.lastIndex = 0;
            let match;
            while ((match = regex.exec(text)) && !token.isCancellationRequested) {
              const start = match.index, end = start + match[0].length;
              if (!match[0].length) regex.lastIndex += text.codePointAt(regex.lastIndex) > 65535 ? 2 : 1;
              if (query.isWordMatch && (/[\p{L}\p{N}_]$/u.test(text.slice(Math.max(0, start - 2), start)) || /^[\p{L}\p{N}_]/u.test(text.slice(end, end + 2)))) continue;
              if (count >= max) return { limitHit: true };
              const a = position(start), b = position(end);
              const previewStart = Math.max(starts[a.line], start - 80);
              const previewEnd = Math.min(starts[b.line + 1] ?? text.length, Math.max(end, previewStart + (options.previewOptions?.charsPerLine || 200)));
              const preview = text.slice(previewStart, previewEnd).replace(/\r?\n$/, "");
              progress.report({ uri, ranges: new vscode2.Range(a.line, a.column, b.line, b.column), preview: {
                text: preview,
                matches: new vscode2.Range(0, start - previewStart, b.line - a.line, b.line === a.line ? end - previewStart : b.column)
              } });
              count++;
            }
          }
          return { limitHit: false, ...unreadable ? { message: { text: unreadable + " \u4E2A\u6587\u4EF6\u9700\u8981\u8BFB\u53D6\u6743\u9650\uFF0C\u8BF7\u68C0\u67E5\u6587\u4EF6\u6743\u9650\u540E\u91CD\u8BD5\u3002", type: 2 } } : {} };
        }
      }));
    };
  }
});

// workbench/extension/gitEngine.js
var require_gitEngine = __commonJS({
  "workbench/extension/gitEngine.js"(exports2) {
    function words(line) {
      const args = [];
      let word = "", quote = "", started = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === "\\" && quote !== "'") {
          if (++i === line.length) throw new Error("\u547D\u4EE4\u672B\u5C3E\u7F3A\u5C11\u8F6C\u4E49\u5B57\u7B26");
          word += line[i];
          started = true;
        } else if (quote) {
          if (c === quote) quote = "";
          else word += c;
        } else if (c === '"' || c === "'") {
          quote = c;
          started = true;
        } else if (/\s/.test(c)) {
          if (started) {
            args.push(word);
            word = "";
            started = false;
          }
        } else {
          if (/[;&|<>`]/.test(c)) throw new Error("\u6B64\u7EC8\u7AEF\u4E0D\u6267\u884C Shell \u7BA1\u9053\u6216\u811A\u672C\uFF0C\u8BF7\u5206\u522B\u8F93\u5165 Git \u547D\u4EE4");
          word += c;
          started = true;
        }
      }
      if (quote) throw new Error("\u5F15\u53F7\u672A\u95ED\u5408");
      if (started) args.push(word);
      return args;
    }
    function path(value, base = "/workspace") {
      if (value.includes("\\") || value.includes("\0")) throw new Error("\u65E0\u6548\u8DEF\u5F84");
      const parts = (value.startsWith("/") ? value : base + "/" + value).split("/"), out = [];
      for (const part of parts) {
        if (!part || part === ".") continue;
        if (part === "..") {
          if (out.length <= 1) throw new Error("\u8DEF\u5F84\u4E0D\u80FD\u79BB\u5F00\u5F53\u524D\u5DE5\u7A0B");
          out.pop();
        } else out.push(part);
      }
      if (out[0] !== "workspace") throw new Error("\u8DEF\u5F84\u4E0D\u80FD\u79BB\u5F00\u5F53\u524D\u5DE5\u7A0B");
      return "/" + out.join("/");
    }
    exports2.createGitEngine = function(native) {
      let cwd = "/workspace";
      return { get cwd() {
        return cwd;
      }, async execute(line) {
        const args = words(line);
        if (!args.length) return { output: "", code: 0 };
        const command = args[0];
        if (command === "git" || command === "help") {
          const argv = command === "help" ? ["git", "--help"] : args;
          return JSON.parse(await native("git_run", { path: cwd, args: argv }));
        }
        if (command === "pwd") return { output: cwd + "\n", code: 0 };
        if (command === "clear") return { output: "\x1B[2J\x1B[H", code: 0 };
        if (command === "cd") {
          const next = path(args[1] || "/workspace", cwd), stat = JSON.parse(await native("fs.stat", { path: next }));
          if (stat.type !== 2) throw new Error("[ArkForge] \u76EE\u6807\u4E0D\u662F\u76EE\u5F55");
          cwd = next;
          return { output: "", code: 0 };
        }
        if (command === "ls") return { output: JSON.parse(await native("fs.list", { path: path(args[1] || ".", cwd) })).map((row) => row[0]).join("\n") + "\n", code: 0 };
        throw new Error("[ArkForge] \u6B64\u7EC8\u7AEF\u8F6C\u53D1\u5B98\u65B9 Git \u547D\u4EE4\uFF1B\u7CFB\u7EDF Shell \u5C1A\u672A\u63A5\u5165");
      } };
    };
    exports2.words = words;
  }
});

// workbench/extension/gitTerminal.js
var require_gitTerminal = __commonJS({
  "workbench/extension/gitTerminal.js"(exports2) {
    var vscode2 = require("vscode");
    var { createGitEngine } = require_gitEngine();
    exports2.registerGitTerminal = function(context, native) {
      function pty() {
        const write = new vscode2.EventEmitter(), close = new vscode2.EventEmitter();
        const engine = createGitEngine(native);
        let line = "", busy = false, closed = false, history = [], index = 0;
        const output = (text) => {
          if (!closed) write.fire(text);
        };
        const prompt = () => output("\x1B[36m" + engine.cwd + "\x1B[0m $ ");
        const run = async (command) => {
          busy = true;
          try {
            const result = await engine.execute(command);
            if (result.output) {
              if (result.code) output("\x1B[31m");
              output(result.output.replace(/\r?\n/g, "\r\n"));
              if (result.code) output("\x1B[0m");
            }
          } catch (error) {
            output("\x1B[31m[ArkForge] " + String(error.message).replace(/[\x00-\x1f\x7f]/g, " ") + "\x1B[0m\r\n");
          } finally {
            busy = false;
            prompt();
          }
        };
        return {
          onDidWrite: write.event,
          onDidClose: close.event,
          open() {
            output("[ArkForge] Official Git CLI \xB7 git --help\r\n");
            prompt();
          },
          close() {
            closed = true;
            write.dispose();
            close.dispose();
          },
          handleInput(data) {
            if (closed) return;
            if (busy) {
              if (data === "") output("\u4EFB\u52A1\u6B63\u5728\u6267\u884C\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u3002\r\n");
              return;
            }
            if (data === "\x1B[A" || data === "\x1B[B") {
              index = Math.max(0, Math.min(history.length, index + (data === "\x1B[A" ? -1 : 1)));
              line = history[index] || "";
              output("\r\x1B[2K");
              prompt();
              output(line);
              return;
            }
            if (data.length > 1 && /[\r\n]/.test(data)) {
              output("\r\n\u8BF7\u9010\u6761\u8F93\u5165\u547D\u4EE4\u3002\r\n");
              prompt();
              line = "";
              return;
            }
            for (const c of data) {
              if (c === "\r" || c === "\n") {
                output("\r\n");
                const command = line;
                line = "";
                if (command.trim()) {
                  history.push(command);
                  index = history.length;
                  run(command);
                } else prompt();
                break;
              }
              if (c === "") {
                line = "";
                output("^C\r\n");
                prompt();
              } else if (c === "\x7F" || c === "\b") {
                if (line) {
                  line = Array.from(line).slice(0, -1).join("");
                  output("\b \b");
                }
              } else if (c >= " " && c !== "\x7F") {
                line += c;
                output(c);
              }
            }
          }
        };
      }
      context.subscriptions.push(vscode2.window.registerTerminalProfileProvider("arkforge.gitTerminal", {
        provideTerminalProfile: () => new vscode2.TerminalProfile({ name: "ArkForge \u7EC8\u7AEF", pty: pty() })
      }));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.openGitTerminal", () => {
        const terminal = vscode2.window.createTerminal({ name: "ArkForge \u7EC8\u7AEF", pty: pty() });
        context.subscriptions.push(terminal);
        terminal.show();
        return terminal;
      }));
    };
  }
});

// workbench/extension/signingSetup.js
var require_signingSetup = __commonJS({
  "workbench/extension/signingSetup.js"(exports2) {
    var vscode2 = require("vscode");
    exports2.registerSigningSetup = function(context, native) {
      const json = async (method, args = {}) => JSON.parse(await native(method, args));
      let configuring = false;
      const status = async () => {
        const value = await json("signing_status");
        await vscode2.commands.executeCommand("setContext", "arkforge.signingReady", value.valid);
        return value;
      };
      const register = (name, run) => context.subscriptions.push(vscode2.commands.registerCommand("arkforge." + name, async () => {
        try {
          return await run();
        } catch (error) {
          vscode2.window.showErrorMessage(error.message);
          return false;
        }
      }));
      const importAndCheck = async (method, args = {}) => {
        const result = await json(method, args);
        if (result.cancelled) return false;
        const checked = await status();
        if (!checked.valid) throw new Error(checked.reason || "\u8BF7\u68C0\u67E5\u5F00\u53D1\u7B7E\u540D\u6750\u6599\u5E76\u91CD\u65B0\u6821\u9A8C");
        vscode2.window.showInformationMessage("\u5F00\u53D1\u7B7E\u540D\u5DF2\u914D\u7F6E\uFF1A" + checked.bundleName + "\u3002\u540E\u7EED\u672C\u673A\u6784\u5EFA\u81EA\u52A8\u7B7E\u540D\u3002");
        return true;
      };
      const manageCertificates = async (prepared, selectedTeam) => {
        if (!prepared) prepared = await json("huawei.prepare");
        const team = selectedTeam || await vscode2.window.showQuickPick(prepared.teams.map((item) => ({ label: item.name, description: item.id, id: item.id })), { title: "\u534E\u4E3A\u8C03\u8BD5\u8BC1\u4E66 \xB7 \u9009\u62E9\u56E2\u961F", ignoreFocusOut: true });
        if (!team) return false;
        const certificates = await json("huawei.certificates", { teamId: team.id });
        const certificate = await vscode2.window.showQuickPick(certificates.names.map((name) => ({ label: name, name })), { title: "\u534E\u4E3A\u8C03\u8BD5\u8BC1\u4E66 \xB7 " + team.label, placeHolder: "\u9009\u62E9\u9700\u8981\u64A4\u9500\u7684\u8BC1\u4E66\uFF1B\u64A4\u9500\u5C06\u5F71\u54CD\u4F7F\u7528\u8BE5\u8BC1\u4E66\u7684\u5E94\u7528", ignoreFocusOut: true });
        if (!certificate) return false;
        const choice = await vscode2.window.showWarningMessage("\u64A4\u9500\u8FD9\u5F20\u534E\u4E3A\u8C03\u8BD5\u8BC1\u4E66\uFF1F", { modal: true, detail: "\u56E2\u961F\uFF1A" + team.label + "\n\u8BC1\u4E66\uFF1A" + certificate.name + "\n\u64A4\u9500\u540E\uFF0C\u8BE5\u8BC1\u4E66\u5C06\u6C38\u4E45\u5931\u6548\u3002\u4F7F\u7528\u8BE5\u8BC1\u4E66\u7684\u8C03\u8BD5\u5E94\u7528\u9700\u8981\u91CD\u65B0\u7B7E\u540D\u3002\u786E\u8BA4\u540E\u64A4\u9500\u4E0A\u65B9\u6240\u9009\u8BC1\u4E66\u3002" }, "\u64A4\u9500\u6B64\u8BC1\u4E66");
        if (choice !== "\u64A4\u9500\u6B64\u8BC1\u4E66") return false;
        await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u6B63\u5728\u64A4\u9500\u6240\u9009\u8C03\u8BD5\u8BC1\u4E66", cancellable: false }, () => json("huawei.revokeCertificate", { teamId: team.id, certName: certificate.name }));
        vscode2.window.showInformationMessage("\u5DF2\u64A4\u9500\uFF1A" + certificate.name + "\u3002\u53EF\u91CD\u65B0\u8FD0\u884C\u534E\u4E3A\u81EA\u52A8\u7B7E\u540D\u7EE7\u7EED\u914D\u7F6E\u3002");
        return true;
      };
      const autoSigning = async (current) => {
        let flow;
        try {
          flow = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u534E\u4E3A\u5F00\u53D1\u8005 \xB7 \u767B\u5F55", cancellable: false }, () => json("huawei.start"));
          if (!flow.authenticated) {
            const signedIn = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u7B49\u5F85\u534E\u4E3A\u7F51\u9875\u767B\u5F55", cancellable: true }, async (progress, token) => {
              const deadline = Date.now() + flow.expiresIn * 1e3;
              progress.report({ message: "\u8BF7\u5728\u534E\u4E3A\u5B98\u65B9\u9875\u9762\u5B8C\u6210\u767B\u5F55\uFF1B\u6388\u6743\u901A\u8FC7\u540E\u8FD4\u56DE ArkForge" });
              while (!token.isCancellationRequested && Date.now() < deadline) {
                await new Promise((resolve) => {
                  const timer = setTimeout(() => {
                    subscription.dispose();
                    resolve();
                  }, 1e3);
                  const subscription = token.onCancellationRequested(() => {
                    clearTimeout(timer);
                    subscription.dispose();
                    resolve();
                  });
                });
                if (token.isCancellationRequested) return false;
                const value = await json("huawei.poll", { id: flow.id });
                if (value.state === "authenticated") return true;
                if (value.state !== "pending") return false;
              }
              if (!token.isCancellationRequested) throw new Error("\u534E\u4E3A\u7F51\u9875\u767B\u5F55\u8D85\u65F6\uFF0C\u8BF7\u91CD\u65B0\u5C1D\u8BD5");
              return false;
            });
            if (!signedIn) return false;
          }
          const prepared = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u8BFB\u53D6\u534E\u4E3A\u5F00\u53D1\u8005\u56E2\u961F\u4E0E\u672C\u673A\u8BBE\u5907", cancellable: false }, () => json("huawei.prepare"));
          const team = await vscode2.window.showQuickPick(prepared.teams.map((item) => ({ label: item.name, description: item.id, id: item.id })), {
            title: "\u534E\u4E3A\u81EA\u52A8\u7B7E\u540D \xB7 \u9009\u62E9\u5F00\u53D1\u8005\u56E2\u961F",
            placeHolder: "\u4E3A " + current.bundleName + " \u9009\u62E9\u7B7E\u540D\u6240\u5C5E\u56E2\u961F",
            ignoreFocusOut: true
          });
          if (!team) return false;
          const udid = prepared.udid || await vscode2.window.showInputBox({ title: "\u534E\u4E3A\u81EA\u52A8\u7B7E\u540D \xB7 \u5F53\u524D\u8BBE\u5907 UDID", prompt: "\u8BF7\u586B\u5199\u5F53\u524D\u8BBE\u5907\u7684 64 \u4F4D\u5341\u516D\u8FDB\u5236 UDID\uFF0C\u53EF\u4ECE\u8BBE\u5907\u8C03\u8BD5\u4FE1\u606F\u4E2D\u83B7\u53D6", ignoreFocusOut: true, validateInput: (value) => /^[A-Fa-f0-9]{64}$/.test(value) ? void 0 : "\u8BF7\u8F93\u5165 64 \u4F4D\u5341\u516D\u8FDB\u5236 UDID" });
          if (!udid) return false;
          const choice = await vscode2.window.showInformationMessage("\u4E3A\u5F53\u524D\u5DE5\u7A0B\u81EA\u52A8\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D\uFF1F", {
            modal: true,
            detail: "\u5E94\u7528\uFF1A" + current.bundleName + "\n\u534E\u4E3A\u8D26\u53F7\uFF1A" + prepared.name + "\n\u56E2\u961F\uFF1A" + team.label + "\n\u8BBE\u5907 UDID\uFF1A" + udid + "\n\u5C06\u5728\u672C\u673A\u751F\u6210\u79C1\u94A5\uFF0C\u5411\u534E\u4E3A\u7533\u8BF7\u8C03\u8BD5\u8BC1\u4E66\u3001\u6CE8\u518C\u672C\u8BBE\u5907\u5E76\u521B\u5EFA Profile\u3002\u6750\u6599\u6821\u9A8C\u901A\u8FC7\u540E\u5E94\u7528\u4E8E\u5F53\u524D\u5DE5\u7A0B\u3002"
          }, "\u7533\u8BF7\u5E76\u914D\u7F6E");
          if (!choice) return false;
          let result;
          try {
            result = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u6B63\u5728\u7533\u8BF7\u534E\u4E3A\u5F00\u53D1\u7B7E\u540D", cancellable: false }, () => json("huawei.issue", { teamId: team.id, udid }));
          } catch (error) {
            if (!/205389872/.test(error.message)) throw error;
            const certificates = await json("huawei.certificates", { teamId: team.id });
            const action = await vscode2.window.showErrorMessage("\u534E\u4E3A\u8C03\u8BD5\u8BC1\u4E66\u5DF2\u8FBE\u5230\u8D26\u53F7\u914D\u989D\uFF08205389872\uFF09", {
              modal: true,
              detail: "\u56E2\u961F\uFF1A" + team.label + "\n\u73B0\u6709\u8BC1\u4E66\uFF1A\n" + certificates.names.map((name) => "\u2022 " + name).join("\n") + "\n\u8BF7\u9009\u62E9\u4E00\u5F20\u95F2\u7F6E\u8BC1\u4E66\uFF0C\u6838\u5BF9\u540E\u64A4\u9500\u4EE5\u91CA\u653E\u914D\u989D\uFF0C\u518D\u91CD\u65B0\u7533\u8BF7\u3002\u53EF\u70B9\u51FB\u201C\u7BA1\u7406\u8C03\u8BD5\u8BC1\u4E66\u2026\u201D\u7EE7\u7EED\u3002"
            }, "\u7BA1\u7406\u8C03\u8BD5\u8BC1\u4E66\u2026");
            if (action === "\u7BA1\u7406\u8C03\u8BD5\u8BC1\u4E66\u2026") await manageCertificates(prepared, team);
            return false;
          }
          if (result.cancelled) return false;
          const checked = await status();
          if (!checked.valid) throw new Error(checked.reason || "\u7B7E\u540D\u6821\u9A8C\u5931\u8D25");
          vscode2.window.showInformationMessage("\u534E\u4E3A\u81EA\u52A8\u7B7E\u540D\u5DF2\u914D\u7F6E\uFF1A" + checked.bundleName + "\u3002\u540E\u7EED\u53EF\u5728\u5E73\u677F\u79BB\u7EBF\u7B7E\u540D\u548C\u6784\u5EFA\u3002");
          return true;
        } finally {
          if (flow?.id) await native("huawei.cancel", { id: flow.id });
        }
      };
      register("configureSigning", async () => {
        if (configuring) return false;
        configuring = true;
        try {
          for (; ; ) {
            const current = await status();
            const item = await vscode2.window.showQuickPick([
              { label: "$(account) \u534E\u4E3A\u8D26\u53F7\u81EA\u52A8\u7B7E\u540D\u2026", description: "\u7F51\u9875\u767B\u5F55 \u2192 \u8FD4\u56DE\u5E73\u677F \u2192 \u81EA\u52A8\u7533\u8BF7\u5E76\u6821\u9A8C\u7B7E\u540D", action: "huawei" },
              { label: "$(settings-gear) \u7BA1\u7406\u534E\u4E3A\u8C03\u8BD5\u8BC1\u4E66\u2026", description: "\u9009\u62E9\u56E2\u961F\u3001\u67E5\u770B\u8BC1\u4E66\u5E76\u786E\u8BA4\u64A4\u9500\uFF0C\u5904\u7406\u914D\u989D\u9650\u5236", action: "huaweiManage" },
              { label: "$(key) \u624B\u52A8\u914D\u7F6E\u7B7E\u540D\u6587\u4EF6\u2026", description: "\u9009\u62E9 .p12\u3001.cer\u3001.p7b\uFF0C\u586B\u5199\u5BC6\u94A5\u522B\u540D\u548C\u5BC6\u7801", action: "files" },
              { label: "$(archive) \u5BFC\u5165\u5DF2\u6709\u7B7E\u540D\u5305\u2026", description: "\u5BFC\u5165\u5DF2\u51C6\u5907\u597D\u7684\u5F00\u53D1\u7B7E\u540D ZIP", action: "zip" },
              { label: "$(refresh) \u91CD\u65B0\u68C0\u67E5\u5F53\u524D\u7B7E\u540D", description: current.valid ? "\u8BC1\u4E66\u6709\u6548\u671F\uFF1A" + current.expires : current.reason, action: "check" },
              { label: "$(copy) \u590D\u5236\u5F53\u524D\u5E94\u7528\u5305\u540D", description: current.bundleName, action: "copy" },
              { label: "$(book) \u67E5\u770B\u5B98\u65B9\u7B7E\u540D\u8BF4\u660E", action: "help" },
              { label: "$(link-external) \u6253\u5F00\u534E\u4E3A\u8BC1\u4E66\u7BA1\u7406\u5E73\u53F0", action: "portal" },
              { label: "$(sign-out) \u6E05\u9664\u672C\u673A\u534E\u4E3A\u767B\u5F55\u51ED\u636E", description: "\u4FDD\u7559\u5DF2\u914D\u7F6E\u7684\u5DE5\u7A0B\u7B7E\u540D", action: "logout" }
            ], { title: "\u5F00\u53D1\u7B7E\u540D \xB7 " + current.bundleName, placeHolder: current.valid ? "\u5DF2\u5C31\u7EEA \xB7 \u6784\u5EFA\u65F6\u81EA\u52A8\u4F7F\u7528\u73B0\u6709\u7B7E\u540D" : "\u9996\u6B21\u914D\u7F6E \xB7 \u8BF7\u9009\u62E9\u7B7E\u540D\u6750\u6599\u7684\u83B7\u53D6\u65B9\u5F0F", ignoreFocusOut: true });
            if (!item) return current.valid;
            if (item.action === "huaweiManage") {
              await manageCertificates();
              continue;
            }
            if (item.action === "copy") {
              await vscode2.env.clipboard.writeText(current.bundleName);
              continue;
            }
            if (item.action === "check") {
              if (current.valid) {
                vscode2.window.showInformationMessage("\u5F53\u524D\u5F00\u53D1\u7B7E\u540D\u6709\u6548\uFF1A" + current.bundleName);
                return true;
              }
              vscode2.window.showWarningMessage(current.reason || "\u8BF7\u914D\u7F6E\u5F53\u524D\u5DE5\u7A0B\u7684\u5F00\u53D1\u7B7E\u540D");
              continue;
            }
            if (item.action === "help") {
              await native("developer_open", { page: "signingHelp" });
              continue;
            }
            if (item.action === "portal") {
              await native("developer_open", { page: "certificates" });
              continue;
            }
            if (item.action === "logout") {
              if (await vscode2.window.showWarningMessage("\u6E05\u9664\u6B64\u5E73\u677F\u4FDD\u5B58\u7684\u534E\u4E3A\u5F00\u53D1\u8005\u767B\u5F55\u51ED\u636E\uFF1F", { modal: true }, "\u9000\u51FA") === "\u9000\u51FA") await native("huawei.logout");
              continue;
            }
            if (item.action === "huawei") {
              if (await autoSigning(current)) return true;
              continue;
            }
            if (item.action === "zip") {
              if (await importAndCheck("import_signing")) return true;
              continue;
            }
            if (item.action === "files") {
              const keyAlias = await vscode2.window.showInputBox({ title: "\u624B\u52A8\u7B7E\u540D \xB7 1/4 \u5BC6\u94A5\u522B\u540D", prompt: "\u586B\u5199\u521B\u5EFA .p12 \u5BC6\u94A5\u5E93\u65F6\u4F7F\u7528\u7684\u522B\u540D", ignoreFocusOut: true, validateInput: (s) => s.trim() && !/[\r\n\0]/.test(s) ? void 0 : "\u8BF7\u8F93\u5165\u6709\u6548\u5BC6\u94A5\u522B\u540D" });
              if (keyAlias === void 0) continue;
              const storePassword = await vscode2.window.showInputBox({ title: "\u624B\u52A8\u7B7E\u540D \xB7 2/4 \u5BC6\u94A5\u5E93\u5BC6\u7801", password: true, ignoreFocusOut: true, prompt: "\u5BC6\u7801\u4FDD\u5B58\u5728\u6B64\u8BBE\u5907\u7684\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93", validateInput: (s) => s ? void 0 : "\u8BF7\u8F93\u5165\u5BC6\u94A5\u5E93\u5BC6\u7801" });
              if (storePassword === void 0) continue;
              const keyPassword = await vscode2.window.showInputBox({ title: "\u624B\u52A8\u7B7E\u540D \xB7 3/4 \u79C1\u94A5\u5BC6\u7801", password: true, ignoreFocusOut: true, prompt: "\u4E0E\u5BC6\u94A5\u5E93\u5BC6\u7801\u76F8\u540C\u65F6\u53EF\u7559\u7A7A" });
              if (keyPassword === void 0) continue;
              const signAlg = await vscode2.window.showInputBox({ title: "\u624B\u52A8\u7B7E\u540D \xB7 4/4 \u7B7E\u540D\u7B97\u6CD5", value: "SHA256withECDSA", ignoreFocusOut: true, prompt: "\u4E0E\u73B0\u6709 DevEco \u7B7E\u540D\u914D\u7F6E\u7684 signAlg \u4FDD\u6301\u4E00\u81F4", validateInput: (s) => /^SHA(256|384)withECDSA$/.test(s) ? void 0 : "\u8BF7\u8F93\u5165\u5B98\u65B9\u7B7E\u540D\u7B97\u6CD5\uFF0C\u5982 SHA256withECDSA" });
              if (signAlg === void 0) continue;
              const choice = await vscode2.window.showInformationMessage("\u4F9D\u6B21\u9009\u62E9\u5BC6\u94A5\u5E93\u3001\u7B7E\u540D\u8BC1\u4E66\u548C Profile", {
                modal: true,
                detail: "\u63A5\u4E0B\u6765\u7CFB\u7EDF\u6587\u4EF6\u9009\u62E9\u5668\u4F9D\u6B21\u9009\u62E9 .p12\u3001.cer\u3001.p7b\u3002Profile \u7684\u5305\u540D\u5FC5\u987B\u4E3A " + current.bundleName + "\uFF0C\u5E76\u5305\u542B\u5F53\u524D\u8C03\u8BD5\u8BBE\u5907\u3002\u53D6\u6D88\u4EFB\u4E00\u6B65\u9AA4\u5747\u4FDD\u7559\u539F\u6709\u7B7E\u540D\u914D\u7F6E\u3002"
              }, "\u9009\u62E9\u7B7E\u540D\u6587\u4EF6");
              if (!choice) continue;
              if (await importAndCheck("signing_import_files", { keyAlias: keyAlias.trim(), storePassword, keyPassword: keyPassword || storePassword, signAlg })) return true;
            }
          }
        } finally {
          configuring = false;
        }
      });
      register("ensureSigning", async () => {
        const current = await status();
        if (current.valid) return true;
        const choice = await vscode2.window.showInformationMessage("\u6784\u5EFA\u524D\u9700\u8981\u914D\u7F6E\u5F53\u524D\u5DE5\u7A0B\u7684\u5F00\u53D1\u7B7E\u540D", {
          modal: true,
          detail: current.bundleName + "\n" + (current.reason || "\u8BF7\u51C6\u5907\u5F53\u524D\u5DE5\u7A0B\u7684\u7B7E\u540D\u6750\u6599") + "\n\u914D\u7F6E\u5B8C\u6210\u540E\u81EA\u52A8\u7EE7\u7EED\u6784\u5EFA\uFF1B\u53D6\u6D88\u5C06\u8FD4\u56DE\u7F16\u8F91\u5668\u3002"
        }, "\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D");
        if (!choice) return false;
        await vscode2.commands.executeCommand("arkforge.configureSigning");
        return (await status()).valid;
      });
      status().then(async (current) => {
        if (current.valid || !context.workspaceState) return;
        const key = "signingOnboarding:" + current.bundleName;
        if (context.workspaceState.get(key)) return;
        await context.workspaceState.update(key, true);
        const choice = await vscode2.window.showInformationMessage("\u9996\u6B21\u4F7F\u7528\u6B64\u5DE5\u7A0B\uFF1A\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D\u540E\u5373\u53EF\u5728\u5E73\u677F\u6784\u5EFA\u5E76\u5B89\u88C5\u3002", "\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D", "\u7A0D\u540E");
        if (choice === "\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D") await vscode2.commands.executeCommand("arkforge.configureSigning");
      }).catch(() => {
      });
    };
  }
});

// workbench/extension/developerSetup.js
var require_developerSetup = __commonJS({
  "workbench/extension/developerSetup.js"(exports2) {
    var vscode2 = require("vscode");
    exports2.registerDeveloperSetup = function(context, native) {
      let signingIn = false;
      const json = async (method, args) => JSON.parse(await native(method, args));
      const open = (page) => native("developer_open", { page });
      const command = (id, run) => context.subscriptions.push(vscode2.commands.registerCommand("arkforge." + id, async () => {
        try {
          return await run();
        } catch (error) {
          vscode2.window.showErrorMessage(error.message);
        }
      }));
      const updateAccount = async () => {
        const account = await json("github.status");
        await vscode2.commands.executeCommand("setContext", "arkforge.githubSignedIn", account.signedIn);
        await vscode2.commands.executeCommand("_arkforge.setAccountProfile", account.signedIn ? { login: account.login, avatar: account.avatar } : void 0);
        return account;
      };
      updateAccount().catch(() => {
      });
      command("verifyGitHub", async () => {
        const account = await json("github.verify");
        await updateAccount();
        return vscode2.window.showInformationMessage("GitHub \u8D26\u6237\u6709\u6548\uFF1A" + account.login);
      });
      command("signOutGitHub", async () => {
        if (await vscode2.window.showWarningMessage("\u9000\u51FA\u5F53\u524D\u5E73\u677F\u4E0A\u7684 GitHub \u8D26\u6237\uFF1F", { modal: true }, "\u9000\u51FA") !== "\u9000\u51FA") return;
        await native("github.logout");
        await updateAccount();
        return vscode2.window.showInformationMessage("\u5DF2\u9000\u51FA\uFF0C\u5E73\u677F\u4FDD\u5B58\u7684 GitHub \u51ED\u636E\u5DF2\u5220\u9664\u3002");
      });
      command("signInGitHub", async () => {
        if (signingIn) return vscode2.window.showInformationMessage("GitHub \u767B\u5F55\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u5B8C\u6210\u6D4F\u89C8\u5668\u4E2D\u7684\u6388\u6743\u6216\u53D6\u6D88\u5F53\u524D\u767B\u5F55\u3002");
        signingIn = true;
        let flow;
        try {
          flow = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u6B63\u5728\u8FDE\u63A5 GitHub", cancellable: false }, () => json("github.start"));
          await vscode2.env.clipboard.writeText(flow.code);
          await open("github");
          const result = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "GitHub\uFF1A\u7B49\u5F85\u7F51\u9875\u6388\u6743", cancellable: true }, async (progress, token) => {
            const deadline = Date.now() + flow.expiresIn * 1e3;
            let interval = flow.interval;
            while (!token.isCancellationRequested && Date.now() < deadline) {
              progress.report({ message: "\u8BBE\u5907\u4EE3\u7801 " + flow.code + " \u5DF2\u590D\u5236 \xB7 \u5728 GitHub \u7F51\u9875\u7C98\u8D34\u5E76\u6388\u6743\u540E\u8FD4\u56DE ArkForge" });
              await new Promise((resolve) => {
                const timer = setTimeout(() => {
                  subscription.dispose();
                  resolve();
                }, interval * 1e3);
                const subscription = token.onCancellationRequested(() => {
                  clearTimeout(timer);
                  subscription.dispose();
                  resolve();
                });
              });
              if (token.isCancellationRequested) return;
              const reply = await json("github.poll", { id: flow.id });
              if (reply.state === "authenticated") return reply;
              if (reply.state !== "authorization_pending") throw new Error("GitHub \u6388\u6743\u5DF2\u7ED3\u675F\uFF1A" + reply.state + "\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55\u3002");
              interval = reply.interval || interval;
            }
            if (!token.isCancellationRequested) throw new Error("GitHub \u8BBE\u5907\u4EE3\u7801\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55\u3002");
          });
          if (result) {
            await updateAccount();
            vscode2.window.showInformationMessage("\u5DF2\u767B\u5F55 GitHub\uFF1A" + result.login + "\u3002\u51ED\u636E\u5DF2\u5B58\u5165\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93\uFF1B\u53EF\u5728\u672C\u673A Git \u7EC8\u7AEF\u8BBF\u95EE\u5DF2\u6388\u6743\u7684 GitHub HTTPS \u4ED3\u5E93\u3002");
          }
        } finally {
          if (flow) await native("github.cancel", { id: flow.id });
          signingIn = false;
        }
      });
      command("configureGit", async () => {
        const account = await json("github.status");
        const item = await vscode2.window.showQuickPick([
          { label: "$(github) \u4F7F\u7528 GitHub \u767B\u5F55", description: account.signedIn ? "\u5F53\u524D\u8D26\u6237\uFF1A" + account.login : "\u5728 GitHub \u5B98\u65B9\u7F51\u9875\u6388\u6743", action: "login" },
          { label: "$(edit) \u8BBE\u7F6E Git \u63D0\u4EA4\u8EAB\u4EFD", description: "\u914D\u7F6E user.name \u548C user.email\uFF0C\u4E0E\u767B\u5F55\u8EAB\u4EFD\u5206\u522B\u7BA1\u7406", action: "identity" },
          { label: "$(key) \u4F7F\u7528\u4E2A\u4EBA\u8BBF\u95EE\u4EE4\u724C", description: "\u9A8C\u8BC1\u4EE4\u724C\u540E\u4FDD\u5B58\u5230\u9E3F\u8499\u52A0\u5BC6\u8D44\u4EA7\u5E93", action: "token" },
          { label: "$(link-external) \u7BA1\u7406 GitHub \u6388\u6743", description: "\u5728 GitHub \u5B98\u65B9\u7F51\u7AD9\u67E5\u770B\u6216\u64A4\u9500\u6743\u9650", action: "access" },
          { label: "$(terminal) \u6253\u5F00\u672C\u673A\u7EC8\u7AEF", description: "\u5B98\u65B9 Shell \u4E0E Git \xB7 \u6587\u4EF6\u64CD\u4F5C\u53CA GitHub HTTPS \u4ED3\u5E93", action: "terminal" },
          ...account.signedIn ? [
            { label: "$(sync) \u6838\u5BF9 GitHub \u767B\u5F55\u72B6\u6001", description: "\u76F4\u8FDE GitHub\uFF0C\u4E34\u8FD1\u8FC7\u671F\u65F6\u81EA\u52A8\u5237\u65B0\u4EE4\u724C", action: "verify" },
            { label: "$(sign-out) \u9000\u51FA " + account.login, description: "\u6E05\u9664\u6B64\u5E73\u677F\u7684\u767B\u5F55\u51ED\u636E\uFF1B\u6388\u6743\u7BA1\u7406\u53EF\u524D\u5F80 GitHub \u5B98\u7F51", action: "logout" }
          ] : []
        ], { title: "Git \xB7 \u8D26\u6237\u4E0E\u63D0\u4EA4\u8EAB\u4EFD", placeHolder: "GitHub \u767B\u5F55\u4E0E Git \u63D0\u4EA4\u8EAB\u4EFD\u662F\u4E24\u9879\u72EC\u7ACB\u914D\u7F6E" });
        if (!item) return;
        if (item.action === "login") return vscode2.commands.executeCommand("arkforge.signInGitHub");
        if (item.action === "access") return open("githubAccess");
        if (item.action === "terminal") return vscode2.commands.executeCommand("arkforge.openGitTerminal");
        if (item.action === "verify") {
          const verified = await json("github.verify");
          return vscode2.window.showInformationMessage("GitHub \u8D26\u6237\u6709\u6548\uFF1A" + verified.login);
        }
        if (item.action === "logout") {
          return vscode2.commands.executeCommand("arkforge.signOutGitHub");
        }
        if (item.action === "token") {
          const choice = await vscode2.window.showQuickPick(["\u8F93\u5165\u5DF2\u6709\u4EE4\u724C", "\u6253\u5F00 GitHub \u521B\u5EFA\u4EE4\u724C"], { title: "GitHub \xB7 \u4E2A\u4EBA\u8BBF\u95EE\u4EE4\u724C" });
          if (!choice) return;
          if (choice === "\u6253\u5F00 GitHub \u521B\u5EFA\u4EE4\u724C") await open("tokens");
          const token = await vscode2.window.showInputBox({ title: "GitHub \xB7 \u4E2A\u4EBA\u8BBF\u95EE\u4EE4\u724C", password: true, ignoreFocusOut: true, prompt: "\u5E73\u677F\u76F4\u8FDE GitHub \u9A8C\u8BC1\u4EE4\u724C\uFF0C\u9A8C\u8BC1\u540E\u4FDD\u5B58\u5230\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93" });
          if (!token) return;
          const result = await json("github.token", { token: token.trim() });
          await updateAccount();
          return vscode2.window.showInformationMessage("\u5DF2\u9A8C\u8BC1 GitHub \u8D26\u6237\uFF1A" + result.login + "\u3002\u53EF\u5728\u672C\u673A Git \u7EC8\u7AEF\u8BBF\u95EE\u5DF2\u6388\u6743\u7684 GitHub HTTPS \u4ED3\u5E93\u3002");
        }
        const name = await vscode2.window.showInputBox({ title: "Git \xB7 \u63D0\u4EA4\u8005\u59D3\u540D", prompt: "\u5199\u5165\u6B64\u5E73\u677F\u7684 Git \u5168\u5C40 user.name", validateInput: (value) => value.trim() && !/[\r\n\0]/.test(value) ? void 0 : "\u8BF7\u8F93\u5165\u6709\u6548\u59D3\u540D" });
        if (name === void 0) return;
        const email = await vscode2.window.showInputBox({ title: "Git \xB7 \u63D0\u4EA4\u8005\u90AE\u7BB1", prompt: "\u53EF\u4F7F\u7528 GitHub \u63D0\u4F9B\u7684 noreply \u90AE\u7BB1", validateInput: (value) => /^[^\s@]+@[^\s@]+$/.test(value) ? void 0 : "\u8BF7\u8F93\u5165\u6709\u6548\u90AE\u7BB1" });
        if (email === void 0) return;
        await native("git_identity", { name: name.trim(), email: email.trim() });
        return vscode2.window.showInformationMessage("Git \u63D0\u4EA4\u8EAB\u4EFD\u5DF2\u4FDD\u5B58\u3002");
      });
      require_signingSetup().registerSigningSetup(context, native);
      command("developerSetup", async () => {
        const item = await vscode2.window.showQuickPick([
          { label: "$(repo) \u914D\u7F6E Git \u4E0E GitHub", description: "\u63D0\u4EA4\u8EAB\u4EFD\u3001\u5B98\u7F51\u767B\u5F55\u3001\u4EE4\u724C\u4E0E\u9000\u51FA", command: "arkforge.configureGit" },
          { label: "$(key) \u914D\u7F6E\u5F53\u524D\u5DE5\u7A0B\u5F00\u53D1\u7B7E\u540D", description: "\u67E5\u770B\u6709\u6548\u6027\u3001\u5B98\u65B9\u8BC1\u4E66\u5E73\u53F0\u3001\u624B\u52A8\u5BFC\u5165", command: "arkforge.configureSigning" },
          { label: "$(book) \u67E5\u770B\u672C\u673A\u6784\u5EFA\u64CD\u4F5C\u6D41\u7A0B", command: "arkforge.buildGuide" }
        ], { title: "ArkForge \xB7 \u5F00\u53D1\u73AF\u5883\u914D\u7F6E", placeHolder: "\u5148\u6253\u5F00 HarmonyOS \u5DE5\u7A0B\uFF0C\u518D\u914D\u7F6E\u5BF9\u5E94\u7684\u5F00\u53D1\u7B7E\u540D" });
        if (item) return vscode2.commands.executeCommand(item.command);
      });
      command("benchmarkSDKStaging", async () => {
        const result = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "\u6D4B\u91CF\u5E73\u677F SDK \u6682\u5B58\u8017\u65F6", cancellable: false }, () => json("benchmark_sdk_staging"));
        await vscode2.window.showInformationMessage("SDK \u6682\u5B58\u5B9E\u6D4B\uFF1A\u91CD\u65B0\u751F\u6210 " + result.rewriteMs + " ms\uFF0C\u6821\u9A8C\u590D\u7528 " + result.reuseMs + " ms\u3002\u6B64\u6570\u636E\u4E3A SDK \u6682\u5B58\u9636\u6BB5\u8017\u65F6\uFF1B\u5B8C\u6574\u6784\u5EFA\u8017\u65F6\u8BF7\u67E5\u770B\u6784\u5EFA\u8F93\u51FA\u3002", { modal: true });
      });
    };
  }
});

// workbench/extension/deviceDebug.js
var require_deviceDebug = __commonJS({
  "workbench/extension/deviceDebug.js"(exports2) {
    var vscode2 = require("vscode");
    exports2.registerDeviceDebug = function(context, native) {
      const output = vscode2.window.createOutputChannel("ArkForge Debug");
      context.subscriptions.push(output);
      let busy = false;
      const state = async () => JSON.parse(await native("debug_state"));
      const display = (value) => {
        output.appendLine(value.status);
        for (const frame of value.frames || []) {
          const source = frame.source;
          output.appendLine("  " + frame.functionName + " " + (source ? source.path + ":" + source.line + ":" + source.column : frame.url + ":" + (frame.location.lineNumber + 1)));
        }
        for (const variable of value.variables || []) output.appendLine("  " + variable.name + " = " + variable.value);
        output.show(true);
      };
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.debug", async () => {
        if (busy) return;
        busy = true;
        try {
          const current = await state();
          const items = current.connected ? [
            { label: current.paused ? "$(debug-continue) \u7EE7\u7EED\u6267\u884C" : "$(debug-pause) \u6682\u505C\u6267\u884C", action: current.paused ? "Debugger.resume" : "Debugger.pause" },
            ...current.paused ? [
              { label: "$(debug-step-over) \u5355\u6B65\u8DF3\u8FC7", action: "Debugger.stepOver" },
              { label: "$(debug-step-into) \u5355\u6B65\u8FDB\u5165", action: "Debugger.stepInto" },
              { label: "$(debug-step-out) \u5355\u6B65\u8DF3\u51FA", action: "Debugger.stepOut" }
            ] : [],
            { label: "$(list-tree) \u67E5\u770B\u8C03\u7528\u6808\u548C\u53D8\u91CF", action: "state" },
            { label: "$(debug-stop) \u65AD\u5F00\u8C03\u8BD5\u8FDE\u63A5", action: "stop" }
          ] : [{ label: "$(debug-start) \u542F\u52A8\u5F53\u524D\u5DE5\u7A0B\u5DF2\u5B89\u88C5\u5E94\u7528\u7684\u8C03\u8BD5", action: "start", description: "\u5148\u901A\u8FC7\u4E09\u89D2\u6309\u94AE\u5B8C\u6210\u6784\u5EFA\u548C\u5B89\u88C5" }];
          const choice = await vscode2.window.showQuickPick(items, { title: "ArkForge \xB7 \u672C\u673A\u8C03\u8BD5", placeHolder: current.status });
          if (!choice) return;
          if (choice.action === "state") {
            display(await state());
            return;
          }
          if (choice.action === "start" && !await vscode2.workspace.saveAll(false)) throw new Error("\u8BF7\u5B8C\u6210\u6587\u4EF6\u4FDD\u5B58\u540E\u542F\u52A8\u8C03\u8BD5");
          await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "ArkForge\uFF1A\u672C\u673A\u8C03\u8BD5", cancellable: false }, () => native("debug_action", { action: choice.action }));
          display(await state());
        } catch (error) {
          output.appendLine(error.message);
          output.show(true);
          vscode2.window.showErrorMessage(error.message);
        } finally {
          busy = false;
        }
      }));
    };
  }
});

// workbench/extension/textEdits.js
var require_textEdits = __commonJS({
  "workbench/extension/textEdits.js"(exports2, module2) {
    function locateUnique(text, fragment) {
      const normalize = (value) => value.replace(/\r+\n/g, "\n");
      const source = normalize(text), needle = normalize(fragment);
      const start = source.indexOf(needle);
      if (!needle || start < 0 || source.indexOf(needle, start + 1) >= 0) throw new Error("\u66FF\u6362\u5185\u5BB9\u672A\u5339\u914D\u6216\u5339\u914D\u591A\u5904\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u5E76\u63D0\u4F9B\u552F\u4E00\u6587\u672C");
      function originalOffset(offset) {
        let removed = 0;
        for (const match of text.matchAll(/\r+\n/g)) {
          if (match.index - removed >= offset) break;
          removed += match[0].length - 1;
        }
        return offset + removed;
      }
      return { start: originalOffset(start), end: originalOffset(start + needle.length) };
    }
    function assertPublicMethodsRetained(before, after) {
      const names = (text) => new Set([...text.matchAll(/^  (?:(?:public|static|async|override)\s+)*([A-Za-z_$][\w$]*)\s*(?:<[^>\n]+>)?\s*\(/gm)].map((match) => match[1]).filter((name) => !["if", "for", "while", "switch", "catch", "constructor"].includes(name)));
      const current = names(after), missing = [...names(before)].filter((name) => !current.has(name));
      if (missing.length) throw new Error("\u8BF7\u4FDD\u7559\u5F53\u524D\u516C\u5F00\u65B9\u6CD5\uFF1A" + missing.join("\u3001") + "\u3002\u4FEE\u6539\u5B9E\u73B0\u53EF\u7CBE\u786E\u66FF\u6362\u65B9\u6CD5\u4F53\uFF1B\u8C03\u6574\u63A5\u53E3\u65F6\u5148\u68C0\u67E5\u8C03\u7528\u65B9\u3002");
    }
    module2.exports = { locateUnique, assertPublicMethodsRetained };
  }
});

// workbench/extension/buildWorkflow.js
var require_buildWorkflow = __commonJS({
  "workbench/extension/buildWorkflow.js"(exports2) {
    var vscode2 = require("vscode");
    exports2.registerBuildWorkflow = function(context, native, output) {
      const steps = [
        { label: "1. \u6253\u5F00\u771F\u5B9E HarmonyOS \u5DE5\u7A0B", description: "\u6253\u5F00\u5DE5\u7A0B ZIP", detail: "\u9009\u62E9 HarmonyOS \u5DE5\u7A0B ZIP\uFF0C\u6839\u76EE\u5F55\u5E94\u5305\u542B build-profile.json5\u3001AppScope \u548C\u5B9E\u9645\u6A21\u5757\u76EE\u5F55\u3002", command: "arkforge.openProject" },
        { label: "2. \u7F16\u8F91\u5E76\u4FDD\u5B58\u6E90\u7801", description: "\u8D44\u6E90\u7BA1\u7406\u5668 \u2192 \u6253\u5F00 .ets \u6587\u4EF6 \u2192 \u4FDD\u5B58", detail: "\u4F7F\u7528 ArkForge \u7F16\u8F91\u5668\u4FEE\u6539\u6E90\u7801\u3002\u6784\u5EFA\u524D\u4F1A\u4FDD\u5B58\u5DE5\u7A0B\u4E2D\u5DF2\u6253\u5F00\u7684\u6587\u4EF6\uFF1B\u4FDD\u5B58\u5931\u8D25\u65F6\u7EC8\u6B62\u6784\u5EFA\u3002", command: "workbench.action.files.saveAll" },
        { label: "3. \u51C6\u5907\u5F00\u53D1\u7B7E\u540D", description: "\u534E\u4E3A\u8D26\u53F7\u81EA\u52A8\u7B7E\u540D\u6216\u624B\u52A8\u5BFC\u5165", detail: "\u9009\u62E9\u534E\u4E3A\u8D26\u53F7\u81EA\u52A8\u7B7E\u540D\uFF0C\u5728\u5B98\u65B9\u7F51\u9875\u767B\u5F55\u540E\u8FD4\u56DE\u5E73\u677F\uFF0C\u9009\u62E9\u5F00\u53D1\u8005\u56E2\u961F\u5E76\u786E\u8BA4\u7533\u8BF7\u3002\u4E5F\u53EF\u624B\u52A8\u5BFC\u5165\u5DF2\u6709\u7B7E\u540D\u3002\u8BF7\u4F7F\u7528\u5339\u914D bundleName\u3001\u5305\u542B\u5F53\u524D\u8BBE\u5907\u4E14\u5728\u6709\u6548\u671F\u5185\u7684\u7B7E\u540D\uFF1B\u5BC6\u7801\u4FDD\u5B58\u5728\u9E3F\u8499\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93\u3002", command: "arkforge.configureSigning" },
        { label: "4. \u68C0\u67E5\u672C\u673A SDK", description: "\u5B98\u65B9 SDK \u68C0\u67E5\u5668\u53CA\u8D44\u6E90\u7F16\u8BD1\u5668\u81EA\u68C0", detail: "\u9A8C\u8BC1\u5E73\u677F\u672C\u673A SDK \u68C0\u67E5\u5668\u7684\u7C7B\u578B\u3001\u8BED\u6CD5\u53CA ArkUI \u89C4\u5219\u68C0\u67E5\u80FD\u529B\uFF0C\u5E76\u81EA\u68C0\u8D44\u6E90\u7F16\u8BD1\u5668\u3002\u5F53\u524D\u5DE5\u7A0B\u7684\u5B8C\u6574\u68C0\u67E5\u5728\u6784\u5EFA\u65F6\u6267\u884C\u3002", command: "arkforge.checkSDK" },
        { label: "5. \u70B9\u51FB\u4E09\u89D2\u6309\u94AE\u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B", description: "\u5DE5\u7A0B\u4E0E\u7B7E\u540D\u68C0\u67E5 \u2192 \u8D44\u6E90\u7F16\u8BD1 \u2192 SDK \u68C0\u67E5 \u2192 ArkUI \u2192 ABC \u2192 HAP \u2192 \u7B7E\u540D \u2192 \u5F39\u7A97\u786E\u8BA4\u5B89\u88C5", detail: "\u70B9\u51FB\u7F16\u8F91\u5668\u4E09\u89D2\u6309\u94AE\u6216\u72B6\u6001\u680F\u300C\u7F16\u8BD1\u5F53\u524D\u5DE5\u7A0B\u300D\uFF0C\u5728\u5E73\u677F\u672C\u673A\u6784\u5EFA\u6210\u529F\u540E\uFF0C\u4F7F\u7528 ArkForge \u5F39\u7A97\u9009\u62E9\u300C\u5B89\u88C5\u5E76\u8FD0\u884C\u300D\u6216\u300C\u4EC5\u5B89\u88C5\u300D\u3002\u9009\u62E9\u5B89\u88C5\u65B9\u5F0F\u540E\u7EE7\u7EED\uFF1B\u9009\u62E9\u53D6\u6D88\u8FD4\u56DE\u7F16\u8F91\u5668\u3002\u5B8C\u6574\u65E5\u5FD7\u4F4D\u4E8E Output \u2192 ArkForge Build\uFF1BSDK \u9519\u8BEF\u540C\u65F6\u8FDB\u5165 Problems\uFF0C\u53EF\u70B9\u51FB\u8FD4\u56DE\u6E90\u7801\u3002\u76F8\u540C\u6784\u5EFA\u8F93\u5165\u4F1A\u590D\u7528\u5DF2\u6821\u9A8C\u7684\u7F13\u5B58\u3002", command: "arkforge.build" },
        { label: "6. \u8FD0\u884C\u5E94\u7528\u5E76\u8FD4\u56DE\u7F16\u8F91\u5668", description: "\u8FD0\u884C\u6700\u8FD1\u5B89\u88C5\u7684\u5E94\u7528", detail: "\u70B9\u51FB\u8FD0\u884C\uFF0C\u5728\u7CFB\u7EDF\u5F39\u7A97\u4E2D\u9009\u62E9\u6253\u5F00\u3002\u901A\u8FC7\u7CFB\u7EDF\u8FD4\u56DE\u624B\u52BF\u6216\u5E94\u7528\u63D0\u4F9B\u7684\u8FD4\u56DE\u5165\u53E3\u56DE\u5230 ArkForge\uFF0C\u7EE7\u7EED\u4FEE\u6539\u548C\u6784\u5EFA\u3002", command: "arkforge.launch" },
        { label: "7. \u672C\u673A\u8C03\u8BD5", description: "\u542F\u52A8\u8C03\u8BD5\u3001\u6682\u505C\u3001\u5355\u6B65\u3001\u8C03\u7528\u6808\u548C\u53D8\u91CF", detail: "\u5148\u6784\u5EFA\u5E76\u5B89\u88C5\u5F53\u524D\u5DE5\u7A0B\uFF0C\u518D\u9009\u62E9\u300CArkForge: \u672C\u673A\u8C03\u8BD5\u2026\u300D\u3002\u8FDE\u63A5\u540E\u518D\u6B21\u6267\u884C\u8BE5\u547D\u4EE4\uFF0C\u53EF\u6682\u505C\u3001\u7EE7\u7EED\u3001\u5355\u6B65\u53CA\u67E5\u770B\u8C03\u7528\u6808\u548C\u53D8\u91CF\uFF1B\u7ED3\u679C\u663E\u793A\u5728 Output \u2192 ArkForge Debug\u3002", command: "arkforge.debug" },
        { label: "8. \u8BFB\u53D6\u8FD0\u884C\u65E5\u5FD7", description: "\u8FD0\u884C\u5931\u8D25\u65F6\u67E5\u770B\u771F\u5B9E\u8BBE\u5907\u65E5\u5FD7", detail: "\u8BFB\u53D6\u6700\u8FD1\u5B89\u88C5\u5E94\u7528\u7684\u672C\u673A\u65E5\u5FD7\u3002\u7F16\u8BD1\u6210\u529F\u3001\u5B89\u88C5\u6210\u529F\u548C\u8FD0\u884C\u6210\u529F\u5206\u522B\u786E\u8BA4\u3002", command: "arkforge.logs" }
      ];
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.buildGuide", async () => {
        const item = await vscode2.window.showQuickPick(steps, { title: "ArkForge \xB7 \u5E73\u677F\u672C\u673A\u6784\u5EFA\u65B9\u6CD5", placeHolder: "\u9009\u62E9\u4E00\u4E2A\u6B65\u9AA4\u67E5\u770B\u8BF4\u660E\u6216\u6267\u884C" });
        if (!item) return;
        const choice = await vscode2.window.showInformationMessage(item.detail, { modal: true }, "\u6267\u884C\u6B64\u6B65\u9AA4", "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA");
        if (choice === "\u6267\u884C\u6B64\u6B65\u9AA4") return vscode2.commands.executeCommand(item.command);
        if (choice === "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA") output.show(true);
      }));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.testBuildWorkflow", async () => {
        const result = await vscode2.window.withProgress({ location: vscode2.ProgressLocation.Notification, title: "ArkForge\uFF1A\u9A8C\u8BC1\u672C\u673A\u6784\u5EFA\u6D41\u7A0B", cancellable: false }, async (progress) => {
          if (!await vscode2.workspace.saveAll(false)) throw new Error("\u6587\u4EF6\u4FDD\u5B58\u5931\u8D25\uFF0C\u6D41\u7A0B\u6D4B\u8BD5\u5DF2\u505C\u6B62");
          if (!await vscode2.commands.executeCommand("arkforge.ensureSigning")) return;
          output.show(true);
          progress.report({ message: "\u68C0\u67E5\u771F\u5B9E HarmonyOS \u5DE5\u7A0B", increment: 10 });
          const project = JSON.parse(await native("project_preflight"));
          output.info("\u5F53\u524D\u5DE5\u7A0B\uFF1A" + project.bundleName + " / " + project.moduleName);
          progress.report({ message: "\u9A8C\u8BC1\u5E73\u677F\u672C\u673A SDK \u548C\u8D44\u6E90\u7F16\u8BD1\u5668", increment: 20 });
          const checked = await native("check_sdk");
          if (!checked.includes("BUILD SUCCESSFUL") || checked.includes("BUILD FAILED")) throw new Error("\u8BF7\u67E5\u770B ArkForge Build \u4E2D\u7684 SDK \u81EA\u68C0\u7ED3\u679C\u5E76\u6309\u63D0\u793A\u5904\u7406");
          progress.report({ message: "\u672C\u673A\u7F16\u8BD1\u3001\u8D44\u6E90\u7F16\u8BD1\u3001\u6253\u5305\u3001\u7B7E\u540D\u548C\u5B89\u88C5", increment: 30 });
          const built = await native("build_project");
          if (!built.includes("BUILD SUCCESSFUL") || built.includes("BUILD FAILED")) throw new Error("\u8BF7\u67E5\u770B Problems \u548C ArkForge Build \u4E2D\u7684\u6784\u5EFA\u5B89\u88C5\u7ED3\u679C\u5E76\u6309\u63D0\u793A\u5904\u7406");
          progress.report({ message: "\u6784\u5EFA\u548C\u5B89\u88C5\u5DF2\u9A8C\u8BC1", increment: 40 });
          return "\u6D41\u7A0B\u6D4B\u8BD5\u901A\u8FC7\uFF1A\u771F\u5B9E\u5DE5\u7A0B\u68C0\u67E5\u3001SDK \u81EA\u68C0\u3001\u672C\u673A\u7F16\u8BD1\u3001\u8D44\u6E90\u5904\u7406\u3001HAP \u6253\u5305\u3001\u7B7E\u540D\u53CA\u5B89\u88C5\u3002\u8FD0\u884C\u7ED3\u679C\u8BF7\u6253\u5F00\u5E94\u7528\u5355\u72EC\u786E\u8BA4\u3002";
        });
        if (!result) return;
        const choice = await vscode2.window.showInformationMessage(result, "\u8FD0\u884C\u5E94\u7528", "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA");
        if (choice === "\u8FD0\u884C\u5E94\u7528") await vscode2.commands.executeCommand("arkforge.launch");
        if (choice === "\u67E5\u770B\u6784\u5EFA\u8F93\u51FA") output.show(true);
        return result;
      }));
    };
  }
});

// workbench/extension/tools.json
var require_tools = __commonJS({
  "workbench/extension/tools.json"(exports2, module2) {
    module2.exports = [
      {
        name: "read_file",
        label: "\u8BFB\u53D6\u5DE5\u7A0B\u6587\u4EF6",
        description: "\u8BFB\u53D6\u6E90\u7801\u53CA\u7248\u672C\uFF1B\u9ED8\u8BA4\u4E00\u6B21\u8BFB\u53D6\u524D 600 \u884C\uFF0C\u53EF\u6307\u5B9A\u8303\u56F4\uFF0C\u5355\u6B21\u6700\u591A 1200 \u884C\u3002\u5C0F\u6587\u4EF6\u53EF\u4E00\u6B21\u8BFB\u5B8C\uFF1B\u591A\u6587\u4EF6\u4F18\u5148 read_files\u3002",
        properties: {
          path: {
            type: "string"
          },
          start_line: {
            type: "integer"
          },
          end_line: {
            type: "integer"
          }
        },
        required: [
          "path"
        ]
      },
      {
        name: "read_files",
        label: "\u6279\u91CF\u8BFB\u53D6\u5DE5\u7A0B\u6E90\u7801",
        description: "\u4E00\u6B21\u8BFB\u53D6 1 \u81F3 6 \u4E2A\u76F8\u5173\u6E90\u7801\u6587\u4EF6\u53CA\u5404\u81EA\u7248\u672C\u3002\u6BCF\u4E2A\u6587\u4EF6\u9ED8\u8BA4 600 \u884C\uFF0C\u6700\u591A 1200 \u884C\uFF1B\u4F18\u5148\u6309\u8BCA\u65AD\u6D89\u53CA\u7684\u6587\u4EF6\u6279\u91CF\u8BFB\u53D6\uFF0C\u51CF\u5C11\u5DE5\u5177\u5F80\u8FD4\u3002",
        properties: {
          files: {
            type: "array",
            minItems: 1,
            maxItems: 6,
            items: {
              type: "object",
              properties: {
                path: {
                  type: "string"
                },
                start_line: {
                  type: "integer"
                },
                end_line: {
                  type: "integer"
                }
              },
              required: [
                "path"
              ]
            }
          }
        },
        required: [
          "files"
        ]
      },
      {
        name: "write_file",
        label: "\u4FDD\u5B58\u5DE5\u7A0B\u6587\u4EF6",
        description: "\u4FDD\u5B58\u5B8C\u6574\u6E90\u7801\u3002\u5DF2\u6709\u6587\u4EF6\u5FC5\u987B\u5148\u5B8C\u6574\u8BFB\u53D6\u5F53\u524D\u7248\u672C\u53CA\u5168\u90E8\u884C\uFF1B\u5C40\u90E8\u4FEE\u6539\u4F18\u5148 replace_text\u3002\u65B0\u6587\u4EF6 expected_version \u4E3A 0\u3002",
        properties: {
          path: {
            type: "string"
          },
          content: {
            type: "string"
          },
          expected_version: {
            type: "integer"
          }
        },
        required: [
          "path",
          "content",
          "expected_version"
        ]
      },
      {
        name: "replace_text",
        label: "\u4FEE\u6539\u6E90\u7801",
        description: "\u7CBE\u786E\u66FF\u6362\u6587\u4EF6\u4E2D\u552F\u4E00\u5339\u914D\u7684\u6587\u672C\uFF0C\u4F7F\u7528\u8BFB\u53D6\u65F6\u7684\u6587\u4EF6\u7248\u672C\u3002",
        properties: {
          path: {
            type: "string"
          },
          old_text: {
            type: "string"
          },
          new_text: {
            type: "string"
          },
          expected_version: {
            type: "integer"
          }
        },
        required: [
          "path",
          "old_text",
          "new_text",
          "expected_version"
        ]
      },
      {
        name: "list_dir",
        label: "\u67E5\u770B\u5DE5\u7A0B\u76EE\u5F55",
        description: "\u5217\u51FA\u5F53\u524D\u5E73\u677F\u5DE5\u7A0B\u76EE\u5F55\u3002",
        properties: {
          path: {
            type: "string"
          }
        },
        required: []
      },
      {
        name: "search_text",
        label: "\u641C\u7D22\u5DE5\u7A0B\u6E90\u7801",
        description: "\u5728\u5F53\u524D\u5E73\u677F\u5DE5\u7A0B\u6E90\u7801\u4E2D\u641C\u7D22\u6587\u672C\u3002",
        properties: {
          query: {
            type: "string"
          }
        },
        required: [
          "query"
        ]
      },
      {
        name: "compile_project",
        label: "\u672C\u673A\u6784\u5EFA\u5E76\u9A8C\u7B7E\uFF08\u4E0D\u5B89\u88C5\uFF09",
        description: "\u4FDD\u5B58\u5F53\u524D\u5DE5\u7A0B\u5E76\u6267\u884C\u5B98\u65B9 SDK \u68C0\u67E5\u3001\u7F16\u8BD1\u3001\u6253\u5305\u3001\u7B7E\u540D\u548C\u9A8C\u7B7E\uFF0C\u4EC5\u751F\u6210\u5F85\u5B89\u88C5 HAP\uFF0C\u4E0D\u5B89\u88C5\u6216\u542F\u52A8\u5E94\u7528\u3002\u7528\u6237\u53EA\u8981\u6C42\u6784\u5EFA\u3001\u68C0\u67E5\u6216\u660E\u786E\u4E0D\u8981\u5B89\u88C5\u65F6\u4F7F\u7528\u6B64\u5DE5\u5177\u3002",
        properties: {},
        required: []
      },
      {
        name: "build_project",
        label: "\u672C\u673A\u6784\u5EFA\u3001\u7B7E\u540D\u5E76\u5B89\u88C5",
        description: "\u5728\u5F53\u524D\u5E73\u677F\u672C\u673A\u4FDD\u5B58\u3001\u68C0\u67E5\u3001\u7F16\u8BD1\u3001\u7B7E\u540D\u5E76\u5B89\u88C5\u771F\u5B9E HarmonyOS \u5DE5\u7A0B\u3002\u5931\u8D25\u540E\u8BFB\u53D6\u9519\u8BEF\u5E76\u4FEE\u590D\u3002",
        properties: {},
        required: []
      },
      {
        name: "read_logs",
        label: "\u8BFB\u53D6\u8FD0\u884C\u65E5\u5FD7",
        description: "\u8BFB\u53D6\u6700\u8FD1\u5B89\u88C5\u5E94\u7528\u7684\u771F\u5B9E\u672C\u673A\u8FD0\u884C\u65E5\u5FD7\u3002",
        properties: {},
        required: []
      },
      {
        name: "get_open_file",
        label: "\u8BFB\u53D6\u5F53\u524D\u7F16\u8F91\u6587\u4EF6",
        description: "\u83B7\u53D6\u5F53\u524D\u7F16\u8F91\u5668\u4E2D\u7684\u6587\u4EF6\u3001\u7248\u672C\u548C\u5185\u5BB9\u3002",
        properties: {},
        required: []
      },
      {
        name: "debug_action",
        label: "\u6267\u884C\u8C03\u8BD5\u64CD\u4F5C",
        description: "\u672C\u673A\u8C03\u8BD5\u64CD\u4F5C\uFF1Astart\u3001stop\u3001Debugger.resume\u3001Debugger.pause\u3001Debugger.stepOver\u3001Debugger.stepInto\u3001Debugger.stepOut\u3002",
        properties: {
          action: {
            type: "string"
          }
        },
        required: [
          "action"
        ]
      },
      {
        name: "debug_state",
        label: "\u67E5\u770B\u8C03\u8BD5\u72B6\u6001",
        description: "\u8BFB\u53D6\u5B9E\u9645\u8C03\u8BD5\u8FDE\u63A5\u72B6\u6001\u3001\u8C03\u7528\u6808\u548C\u53D8\u91CF\u3002",
        properties: {},
        required: []
      },
      {
        name: "get_diagnostics",
        label: "\u8BFB\u53D6\u5168\u9879\u76EE\u5B98\u65B9 SDK \u8BCA\u65AD",
        description: "\u9ED8\u8BA4\u4E00\u6B21\u8BFB\u53D6\u5168\u90E8\u8BCA\u65AD\u7CBE\u7B80\u603B\u89C8\uFF1A\u6309\u6587\u4EF6\u3001\u539F\u56E0\u5206\u7EC4\uFF0C\u4FDD\u7559\u6BCF\u4E00\u5904\u884C\u5217\u4F4D\u7F6E\uFF0C\u65E0\u9700\u9010\u9875\u8BFB\u53D6\u3002\u4F18\u5148 mode=summary\uFF1B\u9700\u8981\u67D0\u6761\u5B8C\u6574\u539F\u59CB\u8BB0\u5F55\u65F6\u4F7F\u7528 mode=details\uFF0C\u5E76\u53EF\u7B5B\u9009 path/category\u3002\u4FEE\u590D\u540E\u91CD\u65B0 compile_project \u66F4\u65B0\u8BCA\u65AD\u3002",
        properties: {
          path: {
            type: "string"
          },
          category: {
            type: "string",
            enum: [
              "warning",
              "error"
            ]
          },
          offset: {
            type: "integer"
          },
          limit: {
            type: "integer"
          },
          mode: {
            type: "string",
            enum: [
              "summary",
              "details"
            ]
          }
        },
        required: []
      },
      {
        name: "create_directory",
        label: "\u521B\u5EFA\u5DE5\u7A0B\u76EE\u5F55",
        description: "\u5728\u5F53\u524D\u5DE5\u7A0B\u4E2D\u521B\u5EFA\u76EE\u5F55\u548C\u7236\u76EE\u5F55\u3002",
        properties: {
          path: {
            type: "string"
          }
        },
        required: [
          "path"
        ]
      },
      {
        name: "rename_file",
        label: "\u91CD\u547D\u540D\u6216\u79FB\u52A8\u5DE5\u7A0B\u6587\u4EF6",
        description: "\u5148\u8BFB\u53D6\u6587\u4EF6\u7248\u672C\uFF0C\u518D\u5728\u5F53\u524D\u5DE5\u7A0B\u5185\u79FB\u52A8\u6216\u91CD\u547D\u540D\u6587\u4EF6\u3002\u4FDD\u7559\u5DF2\u6709\u76EE\u6807\u6587\u4EF6\uFF0C\u5E76\u4FDD\u5B58\u6E90\u6587\u4EF6\u5386\u53F2\u3002",
        properties: {
          path: {
            type: "string"
          },
          new_path: {
            type: "string"
          },
          expected_version: {
            type: "integer"
          }
        },
        required: [
          "path",
          "new_path",
          "expected_version"
        ]
      },
      {
        name: "delete_file",
        label: "\u5220\u9664\u5DE5\u7A0B\u6587\u4EF6",
        description: "\u5148\u8BFB\u53D6\u6587\u4EF6\u7248\u672C\uFF0C\u7ECF\u7528\u6237\u786E\u8BA4\u540E\u5220\u9664\u4E00\u4E2A\u666E\u901A\u6587\u4EF6\uFF1B\u6E90\u6587\u4EF6\u4F1A\u4FDD\u7559\u672C\u5730\u5386\u53F2\u3002",
        properties: {
          path: {
            type: "string"
          },
          expected_version: {
            type: "integer"
          }
        },
        required: [
          "path",
          "expected_version"
        ]
      }
    ];
  }
});

// workbench/extension/agentContext.js
var require_agentContext = __commonJS({
  "workbench/extension/agentContext.js"(exports2, module2) {
    var defaults = { contextWindow: 64e3, maxOutputTokens: 8192, compressionThreshold: 0.75 };
    function settings(vscode2) {
      const config = vscode2.workspace.getConfiguration?.("arkforge.agent");
      const contextWindow = Math.max(16384, Math.min(1048576, Number(config?.get("contextWindow", defaults.contextWindow)) || defaults.contextWindow));
      return {
        contextWindow,
        maxOutputTokens: Math.max(1024, Math.min(32768, Math.floor(contextWindow / 4), Number(config?.get("maxOutputTokens", defaults.maxOutputTokens)) || defaults.maxOutputTokens)),
        compressionThreshold: Math.max(0.5, Math.min(0.9, Number(config?.get("compressionThreshold", defaults.compressionThreshold)) || defaults.compressionThreshold))
      };
    }
    function historyLimit(context = defaults) {
      return Math.max(6e3, Math.min(14e4, Math.floor((context.contextWindow - context.maxOutputTokens - 4e3) * context.compressionThreshold)));
    }
    module2.exports = { settings, historyLimit, defaults };
  }
});

// workbench/extension/agentLoop.js
var require_agentLoop = __commonJS({
  "workbench/extension/agentLoop.js"(exports2, module2) {
    var HISTORY_LIMIT = 36e3;
    var { historyLimit } = require_agentContext();
    var MUTATIONS = /* @__PURE__ */ new Set(["write_file", "replace_text", "create_directory", "rename_file", "delete_file"]);
    var BUILDS = /* @__PURE__ */ new Set(["compile_project", "build_project"]);
    function toolSummary(call, result) {
      let input = {};
      try {
        input = JSON.parse(call.function.arguments || "{}");
      } catch (_) {
      }
      const detail = result.length > 900 ? result.slice(0, 300) + " \u2026 " + result.slice(-600) : result;
      return call.function.name + (input.path ? " " + input.path : "") + ": " + detail;
    }
    function compactHistory(messages, state, limit = HISTORY_LIMIT) {
      if (JSON.stringify(messages).length <= limit) return messages;
      const groups = [];
      for (const message of messages) {
        if (message.role === "tool" && groups.length) groups[groups.length - 1].push(message);
        else groups.push([message]);
      }
      const reserve = Math.min(1500, Math.floor(limit / 4));
      let used = 0;
      const recent = [];
      for (let i = groups.length - 1; i >= 0; i--) {
        const bytes = JSON.stringify(groups[i]).length;
        if (used + bytes > limit - reserve - 1e3) break;
        recent.unshift(...groups[i]);
        used += bytes;
      }
      const summaryBudget = Math.min(10500, Math.max(500, limit - used - 1e3));
      const summary = {
        goal: state.goal,
        revision: state.revision,
        lastBuild: state.lastBuild,
        diagnosticProgress: Object.fromEntries(Object.entries(state.diagnosticProgress || {}).map(([key, p]) => [key, { matched: p.matched, nextOffset: p.nextOffset, complete: p.complete, files: p.files.slice(0, 12) }])),
        recentOperations: (state.operations || []).slice(-12).reverse(),
        instruction: "\u7EE7\u7EED\u539F\u4EFB\u52A1\u3002\u5386\u53F2\u6E90\u7801\u4EC5\u4F5C\u8BB0\u5F55\uFF0C\u4FEE\u6539\u524D\u91CD\u65B0\u8BFB\u53D6\u5F53\u524D\u6587\u4EF6\u53CA\u7248\u672C\u3002\u4F7F\u7528 get_diagnostics(mode=summary) \u4E00\u6B21\u67E5\u770B\u5269\u4F59\u8BCA\u65AD\uFF0C\u518D read_files \u6279\u91CF\u8BFB\u53D6\u76F8\u5173\u6E90\u7801\uFF0C\u6700\u7EC8\u91CD\u65B0\u7F16\u8BD1\u9A8C\u8BC1\u3002"
      };
      return [{ role: "user", content: "\u4EFB\u52A1\u8FDB\u5EA6\u68C0\u67E5\u70B9\uFF1A\n" + JSON.stringify(summary).slice(0, summaryBudget) }, ...recent];
    }
    function needsVerification(state) {
      if (!state.verifyBuild) return "";
      const build = state.lastBuild;
      if (!build || build.revision !== state.revision) return "\u8BF7\u8C03\u7528 compile_project \u9A8C\u8BC1\u5F53\u524D\u4FEE\u6539\uFF0C\u518D\u6838\u5BF9 get_diagnostics\uFF0C\u5B8C\u6210\u540E\u6C47\u62A5\u5B9E\u9645\u7ED3\u679C\u3002";
      if (!build.ok) return "\u5F53\u524D\u6784\u5EFA\u5C1A\u6709\u9519\u8BEF\u3002\u8BF7\u8BFB\u53D6\u771F\u5B9E\u8BCA\u65AD\uFF0C\u4FEE\u590D\u5E76\u91CD\u65B0\u8C03\u7528 compile_project\u3002";
      if (state.warningFree && (!build.diagnosticsKnown || build.errors || build.warnings)) {
        return "\u672C\u8F6E\u76EE\u6807\u662F\u6E05\u7406\u5168\u90E8 warnings\u3002\u5F53\u524D\u6784\u5EFA\u68C0\u67E5\uFF1A" + JSON.stringify(build) + "\u3002\u8BF7\u7528 get_diagnostics(mode=summary) \u6C47\u603B\u5269\u4F59\u8BCA\u65AD\uFF0C\u6309\u6587\u4EF6\u4FEE\u590D\u540E\u91CD\u65B0\u7F16\u8BD1\u3002\u4FDD\u7559\u68C0\u67E5\u89C4\u5219\u548C\u5E94\u7528\u884C\u4E3A\u3002";
      }
      return "";
    }
    async function runAgentTask(options) {
      const { token, stream, query, invoke, diagnostics, workspace, checkpoint, system } = options;
      let messages = options.messages.slice();
      const state = options.state ? { ...options.state, operations: [...options.state.operations || []] } : {
        goal: options.goal,
        revision: 0,
        operations: [],
        verifyBuild: /编译|构建|warnings?|警告|compile|build/i.test(options.goal),
        warningFree: /(?:所有|全部|清理|消除|修复|解决|all|zero|remove|fix).{0,30}(?:warnings?|警告)|(?:warnings?|警告).{0,30}(?:全部|清零|清理|all|zero)/i.test(options.goal)
      };
      const allowInstall = /安装|install/i.test(state.goal) && !/(?:不要|不|无需|禁止).{0,4}安装|do not install|without install/i.test(state.goal);
      state.operations ||= [];
      let noTools = 0, repeated = 0, fingerprint = "", rounds = 0;
      let visits = /* @__PURE__ */ new Map();
      let limit = options.context ? historyLimit(options.context) : HISTORY_LIMIT;
      let contextRetries = 0;
      const compact = () => {
        let effectiveLimit = limit;
        const pressure = options.context && state.usage?.prompt_tokens >= (options.context.contextWindow - options.context.maxOutputTokens) * options.context.compressionThreshold;
        if (pressure && state.compactedUsage !== state.usageSerial) {
          effectiveLimit = Math.max(6e3, Math.min(limit, Math.floor(JSON.stringify(messages).length * 0.65)));
          state.compactedUsage = state.usageSerial;
        }
        const next = compactHistory(messages, state, effectiveLimit);
        if (next !== messages) {
          state.compactions = (state.compactions || 0) + 1;
          stream.progress("\u6B63\u5728\u6574\u7406\u957F\u5BF9\u8BDD\u4E0A\u4E0B\u6587\uFF0C\u4FDD\u7559\u4EFB\u52A1\u76EE\u6807\u3001\u4FEE\u6539\u8BB0\u5F55\u548C\u6700\u65B0\u8BCA\u65AD");
        }
        messages = next;
      };
      const save = async (status) => {
        compact();
        const data = { workspace, messages, taskState: { ...state, status }, updatedAt: Date.now() };
        try {
          await checkpoint?.(data);
        } catch (_) {
          stream.progress("\u4EFB\u52A1\u8FDB\u5EA6\u4FDD\u7559\u5728\u5F53\u524D\u4F1A\u8BDD\uFF0C\u6B63\u5728\u7EE7\u7EED\u5904\u7406");
        }
        return { metadata: data };
      };
      try {
        while (!token.isCancellationRequested) {
          compact();
          stream.progress("\u6B63\u5728\u5904\u7406\u5DE5\u7A0B \xB7 \u7B2C " + ++rounds + " \u8F6E");
          let response;
          try {
            response = await query([{ role: "system", content: system }, ...messages], token);
            contextRetries = 0;
          } catch (error) {
            if (!token.isCancellationRequested && /context.{0,30}(?:length|window|limit)|maximum.{0,30}tokens|too many tokens|上下文.{0,10}(?:超|限制)/i.test(error.message) && contextRetries++ < 3 && limit > 6e3) {
              limit = Math.max(6e3, Math.floor(limit * 0.6));
              messages = compactHistory(messages, state, limit);
              state.compactions = (state.compactions || 0) + 1;
              stream.progress("\u6B63\u5728\u6309\u6A21\u578B\u989D\u5EA6\u6574\u7406\u4E0A\u4E0B\u6587\uFF0C\u968F\u540E\u7EE7\u7EED\u5F53\u524D\u4EFB\u52A1");
              continue;
            }
            throw error;
          }
          if (response.__usage) {
            state.usage = response.__usage;
            state.usageSerial = (state.usageSerial || 0) + 1;
          }
          if (token.isCancellationRequested) break;
          const calls = response.tool_calls || [];
          messages.push({ role: "assistant", content: response.content || "", ...calls.length ? { tool_calls: calls } : {} });
          if (response.content) stream.markdown(response.content);
          if (!calls.length) {
            const pending = needsVerification(state);
            if (!pending) return await save("completed");
            if (++noTools >= 3) {
              stream.markdown("\n\u5DF2\u4FDD\u5B58\u5F53\u524D\u4FEE\u6539\u548C\u68C0\u67E5\u8FDB\u5EA6\u3002" + pending);
              stream.button?.({ command: "arkforge.resumeAgent", title: "\u7EE7\u7EED\u4FEE\u590D\u5E76\u9A8C\u8BC1" });
              return await save("paused");
            }
            messages.push({ role: "user", content: pending });
            continue;
          }
          noTools = 0;
          const outcomes = [];
          const guidance = [];
          let cycling = false;
          for (const call of calls) {
            let result, input = {};
            if (token.isCancellationRequested) result = "\u7528\u6237\u5DF2\u505C\u6B62\u672C\u8F6E\u4EFB\u52A1\uFF0C\u6B64\u5DE5\u5177\u5C1A\u672A\u6267\u884C\u3002";
            else {
              try {
                input = JSON.parse(call.function.arguments || "{}");
                if (call.function.name === "build_project" && !allowInstall) throw new Error("\u672C\u8F6E\u4F7F\u7528 compile_project \u5B8C\u6210\u7F16\u8BD1\u68C0\u67E5\u3002\u9700\u8981\u5B89\u88C5\u65F6\u7531\u7528\u6237\u53D1\u8D77\u5B89\u88C5\u64CD\u4F5C\u3002");
                if (MUTATIONS.has(call.function.name)) state.revision++;
                if (BUILDS.has(call.function.name)) {
                  state.lastBuild = { ok: false, revision: state.revision, diagnosticsKnown: false };
                  state.diagnosticProgress = {};
                }
                result = String(await invoke(call.function.name, input));
                if (MUTATIONS.has(call.function.name)) visits.clear();
                if (BUILDS.has(call.function.name)) {
                  const ok = /BUILD SUCCESSFUL/.test(result) && !/BUILD FAILED/.test(result);
                  let items;
                  try {
                    items = await diagnostics();
                  } catch (_) {
                  }
                  state.lastBuild = {
                    ok,
                    revision: state.revision,
                    diagnosticsKnown: Array.isArray(items),
                    warnings: items?.filter((d) => d.category === 0).length,
                    errors: items?.filter((d) => d.category === 1).length
                  };
                  result += "\n\u5F53\u524D\u6784\u5EFA\u8BCA\u65AD\u6C47\u603B\uFF1A" + JSON.stringify(state.lastBuild);
                }
                if (call.function.name === "get_diagnostics") {
                  const page = JSON.parse(result), key = (input.category || "all") + ":" + (input.path || "*");
                  state.diagnosticProgress ||= {};
                  const progress = state.diagnosticProgress[key] || { matched: page.matched, ranges: [], files: [] };
                  progress.matched = page.matched;
                  const items = page.diagnostics || [];
                  if (page.mode === "summary") progress.ranges = [[0, page.matched]];
                  else progress.ranges.push([page.offset, page.offset + items.length]);
                  progress.ranges.sort((a, b) => a[0] - b[0]);
                  const merged = [];
                  for (const range of progress.ranges) {
                    const last = merged[merged.length - 1];
                    if (last && range[0] <= last[1]) last[1] = Math.max(last[1], range[1]);
                    else merged.push(range.slice());
                  }
                  progress.ranges = merged;
                  progress.nextOffset = merged[0]?.[0] === 0 ? merged[0][1] : 0;
                  progress.complete = progress.nextOffset >= page.matched;
                  progress.files = [.../* @__PURE__ */ new Set([...progress.files, ...page.mode === "summary" ? page.groups.map((item) => item.path) : items.map((item) => item.fileName)])].slice(0, 150);
                  state.diagnosticProgress[key] = progress;
                  result += "\n\u8BCA\u65AD\u9605\u8BFB\u8FDB\u5EA6\uFF1A" + JSON.stringify({ matched: progress.matched, nextOffset: progress.nextOffset, complete: progress.complete });
                  if (progress.complete) result += "\n\u6B64\u7B5B\u9009\u4E0B\u7684\u5168\u90E8\u8BCA\u65AD\u5DF2\u8BFB\u53D6\u3002\u8BF7\u9009\u5B9A\u6587\u4EF6\u8BFB\u53D6\u6E90\u7801\u3001\u4FEE\u590D\u540E\u91CD\u65B0\u6784\u5EFA\uFF1B\u6784\u5EFA\u540E\u8BCA\u65AD\u9875\u4F1A\u66F4\u65B0\u3002";
                }
              } catch (error) {
                result = "\u5DE5\u5177\u5931\u8D25\uFF1A" + error.message;
              }
            }
            const summary = toolSummary(call, result);
            outcomes.push(summary);
            const signature = call.function.name + JSON.stringify(Object.fromEntries(Object.entries(input).sort(([a], [b]) => a.localeCompare(b)))) + summary;
            const count = (visits.get(signature) || 0) + 1;
            visits.set(signature, count);
            if (count === 4) guidance.push({ role: "user", content: "\u6B64\u5DE5\u5177\u53CA\u7ED3\u679C\u5DF2\u7ECF\u91CD\u590D\u8BFB\u53D6\u591A\u6B21\u3002\u8BF7\u4F9D\u636E\u5DF2\u4FDD\u5B58\u7684\u8BCA\u65AD\u9605\u8BFB\u8FDB\u5EA6\u9009\u62E9\u672A\u5904\u7406\u7684\u6587\u4EF6\uFF0C\u6267\u884C\u5B9E\u9645\u4FEE\u590D\u6216\u8BF4\u660E\u9700\u8981\u8865\u5145\u7684\u4FE1\u606F\u3002" });
            if (count >= 8) cycling = true;
            state.operations.push(summary);
            state.operations = state.operations.slice(-24);
            const resultLimit = Math.max(1e3, Math.min(9e4, Math.floor((limit - 3500) / calls.length)));
            const prefix = Math.floor(resultLimit / 4);
            const content = result.length > resultLimit ? result.slice(0, prefix) + "\n[\u4E2D\u95F4\u8F93\u51FA\u5DF2\u7701\u7565\uFF1B\u8BF7\u6309\u8F83\u5C0F\u884C\u8303\u56F4\u6216\u8BCA\u65AD\u9875\u7801\u8BFB\u53D6\u540E\u7EED\u5185\u5BB9]\n" + result.slice(-(resultLimit - prefix)) : result;
            messages.push({ role: "tool", tool_call_id: call.id, content });
          }
          messages.push(...guidance);
          await save(token.isCancellationRequested ? "cancelled" : "running");
          if (cycling) {
            stream.markdown("\n\u5DF2\u4FDD\u5B58\u4FEE\u6539\u548C\u8BCA\u65AD\u8FDB\u5EA6\u3002\u5F53\u524D\u5DE5\u5177\u7ED3\u679C\u591A\u6B21\u91CD\u590D\uFF0C\u8BF7\u8865\u5145\u5904\u7406\u65B9\u5411\u540E\u7EE7\u7EED\u3002");
            stream.button?.({ command: "arkforge.resumeAgent", title: "\u7EE7\u7EED\u5F53\u524D\u4EFB\u52A1" });
            return await save("paused");
          }
          const current = outcomes.join("\n");
          repeated = current === fingerprint ? repeated + 1 : 0;
          fingerprint = current;
          if (repeated === 4) messages.push({ role: "user", content: "\u6700\u8FD1\u5DE5\u5177\u6B65\u9AA4\u548C\u7ED3\u679C\u91CD\u590D\uFF0C\u8BF7\u66F4\u6362\u6392\u67E5\u65B9\u6CD5\uFF0C\u68C0\u67E5\u6587\u4EF6\u7248\u672C\u6216\u5177\u4F53\u8BCA\u65AD\u540E\u7EE7\u7EED\u63A8\u8FDB\u3002" });
          if (repeated >= 8) {
            stream.markdown("\n\u5F53\u524D\u6B65\u9AA4\u8FDE\u7EED\u8FD4\u56DE\u76F8\u540C\u7ED3\u679C\uFF0C\u4FEE\u6539\u548C\u8BCA\u65AD\u8FDB\u5EA6\u5DF2\u4FDD\u5B58\u3002\u53EF\u4EE5\u8865\u5145\u5904\u7406\u65B9\u5411\u540E\u7EE7\u7EED\u3002");
            stream.button?.({ command: "arkforge.resumeAgent", title: "\u7EE7\u7EED\u5F53\u524D\u4EFB\u52A1" });
            return await save("paused");
          }
        }
        return await save("cancelled");
      } catch (error) {
        const result = await save(token.isCancellationRequested ? "cancelled" : "error");
        if (!token.isCancellationRequested) {
          result.errorDetails = { message: error.message };
          stream.button?.({ command: "arkforge.resumeAgent", title: "\u4ECE\u5F53\u524D\u8FDB\u5EA6\u7EE7\u7EED" });
        }
        return result;
      }
    }
    function cancellableDelay(ms, token) {
      return new Promise((resolve, reject) => {
        if (token.isCancellationRequested) return reject(new Error("\u4EFB\u52A1\u5DF2\u505C\u6B62"));
        let subscription;
        const timer = setTimeout(() => {
          subscription?.dispose();
          resolve();
        }, ms);
        subscription = token.onCancellationRequested(() => {
          clearTimeout(timer);
          subscription?.dispose();
          reject(new Error("\u4EFB\u52A1\u5DF2\u505C\u6B62"));
        });
      });
    }
    module2.exports = { runAgentTask, compactHistory, needsVerification, cancellableDelay };
  }
});

// workbench/extension/nativeChat.js
var require_nativeChat = __commonJS({
  "workbench/extension/nativeChat.js"(exports2) {
    var vscode2 = require("vscode");
    var tools = require_tools();
    var { runAgentTask, cancellableDelay } = require_agentLoop();
    var agentContext = require_agentContext();
    exports2.registerNativeChat = function(context, native, agentTool, output) {
      const config = async () => JSON.parse(await native("agent_config_get"));
      const schema = (tool) => ({ type: "object", properties: tool.properties, required: tool.required, additionalProperties: false });
      const modelEvents = new vscode2.EventEmitter();
      context.subscriptions.push(modelEvents);
      for (const tool of tools) context.subscriptions.push(vscode2.lm.registerTool("arkforge_" + tool.name, {
        prepareInvocation: (options) => ({ invocationMessage: tool.label, ...tool.name === "delete_file" ? { confirmationMessages: { title: "\u5220\u9664\u5DE5\u7A0B\u6587\u4EF6", message: "\u5220\u9664 " + options.input.path + "\u3002\u6E90\u6587\u4EF6\u4F1A\u5148\u4FDD\u7559\u4E00\u4EFD\u672C\u5730\u5386\u53F2\u3002" } } : {} }),
        invoke: async (options, token) => {
          if (token.isCancellationRequested) throw new vscode2.CancellationError();
          const result = await agentTool(tool.name, options.input);
          return new vscode2.LanguageModelToolResult([new vscode2.LanguageModelTextPart(result)]);
        }
      }));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.configureAgentContext", () => vscode2.commands.executeCommand("workbench.action.openSettings", "arkforge.agent")));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.configureAgent", async () => {
        const previous = await config();
        const base = await vscode2.window.showInputBox({ title: "ArkForge \xB7 \u6A21\u578B API \u5730\u5740", value: previous.base, prompt: "\u586B\u5199\u6A21\u578B\u670D\u52A1\u7684 HTTPS API \u5730\u5740\uFF0C\u5E73\u677F\u5C06\u76F4\u63A5\u8FDE\u63A5", validateInput: (value) => /^https:\/\/[^\s]+$/.test(value) ? void 0 : "\u8BF7\u8F93\u5165 HTTPS API \u5730\u5740" });
        if (base === void 0) return;
        const model = await vscode2.window.showInputBox({ title: "ArkForge \xB7 \u6A21\u578B\u540D\u79F0", value: previous.model, validateInput: (value) => value.trim() ? void 0 : "\u8BF7\u8F93\u5165\u6A21\u578B\u540D\u79F0" });
        if (model === void 0) return;
        const key = await vscode2.window.showInputBox({ title: "ArkForge \xB7 API Key", password: true, ignoreFocusOut: true, prompt: previous.hasKey ? "\u7559\u7A7A\u4FDD\u7559\u5DF2\u4FDD\u5B58\u5BC6\u94A5\uFF1B\u5BC6\u94A5\u5B58\u5165\u9E3F\u8499\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93" : "\u5BC6\u94A5\u4FDD\u5B58\u5728\u9E3F\u8499\u7CFB\u7EDF\u52A0\u5BC6\u8D44\u4EA7\u5E93" });
        if (key === void 0) return;
        await native("agent_config_save", { base: base.trim(), model: model.trim(), key: key.trim() });
        modelEvents.fire();
        vscode2.window.showInformationMessage("\u6A21\u578B\u914D\u7F6E\u5DF2\u4FDD\u5B58\u3002\u6587\u4EF6\u3001\u6784\u5EFA\u3001\u7B7E\u540D\u3001\u5B89\u88C5\u548C\u65E5\u5FD7\u5DE5\u5177\u5728\u5E73\u677F\u672C\u673A\u6267\u884C\u3002");
      }));
      async function query(messages, token, options = {}) {
        if (token.isCancellationRequested) throw new vscode2.CancellationError();
        const settings = await config();
        if (token.isCancellationRequested) throw new vscode2.CancellationError();
        if (!settings.hasKey) throw new Error("\u8BF7\u8FD0\u884C\u201CArkForge: \u914D\u7F6E DeepSeek / \u6A21\u578B API\u201D\u586B\u5199\u5BC6\u94A5\uFF0C\u5373\u53EF\u4F7F\u7528 Agent\u3002\u672C\u673A\u6784\u5EFA\u548C\u6D41\u7A0B\u6D4B\u8BD5\u53EF\u76F4\u63A5\u4F7F\u7528\u3002");
        const stop = token.onCancellationRequested(() => native("cancel_model").catch(() => {
        }));
        try {
          const contextSettings = agentContext.settings(vscode2);
          let maxTokens = contextSettings.maxOutputTokens;
          for (let attempt = 0; attempt < 4; attempt++) {
            if (token.isCancellationRequested) throw new vscode2.CancellationError();
            try {
              const body = { model: settings.model, stream: false, max_tokens: maxTokens, messages, ...options };
              if (settings.base.includes("api.deepseek.com")) body.thinking = { type: "disabled" };
              const response = JSON.parse(await native("chat", { base: settings.base, body: JSON.stringify(body) }));
              const choice = response.choices?.[0];
              if (!choice?.message) throw new Error("\u6A21\u578B\u672A\u8FD4\u56DE\u6709\u6548\u6D88\u606F");
              if (choice.finish_reason === "length") {
                maxTokens = Math.min(maxTokens * 2, 32768);
                throw new Error("\u6A21\u578B\u8F93\u51FA\u8FBE\u5230\u957F\u5EA6\u9650\u5236\uFF0C\u6B63\u5728\u6269\u5927\u8F93\u51FA\u7A97\u53E3");
              }
              if (choice.finish_reason === "content_filter") throw new Error("\u6A21\u578B\u670D\u52A1\u8981\u6C42\u8C03\u6574\u672C\u8F6E\u8BF7\u6C42\u5185\u5BB9");
              if (["insufficient_system_resource", "aborted"].includes(choice.finish_reason)) throw new Error("\u6A21\u578B\u670D\u52A1\u6682\u65F6\u4E2D\u65AD\uFF1A" + choice.finish_reason);
              for (const call of choice.message.tool_calls || []) JSON.parse(call.function.arguments || "{}");
              return { ...choice.message, __usage: response.usage };
            } catch (error) {
              if (token.isCancellationRequested) throw new vscode2.CancellationError();
              const retry = /HTTP (408|429|500|502|503|504)|timeout|timed out|超时|connect.*fail|network|socket|2300028|2300007|2300006|2300052|输出达到长度限制|insufficient_system_resource|aborted/i.test(error.message);
              if (!retry || attempt === 3) throw error;
              output.info("\u6A21\u578B\u8FDE\u63A5\u91CD\u8BD5 " + (attempt + 1) + " / 3\uFF1A" + error.message);
              await cancellableDelay([1e3, 3e3, 8e3][attempt], token);
            }
          }
        } finally {
          stop.dispose();
        }
      }
      context.subscriptions.push(vscode2.lm.registerLanguageModelChatProvider("arkforge-deepseek", {
        onDidChangeLanguageModelChatInformation: modelEvents.event,
        provideLanguageModelChatInformation: async () => {
          const settings = await config(), limits = agentContext.settings(vscode2);
          return [{ id: settings.model, name: settings.model, family: "deepseek", isDefault: true, isUserSelectable: true, version: "1", maxInputTokens: limits.contextWindow - limits.maxOutputTokens, maxOutputTokens: limits.maxOutputTokens, capabilities: { toolCalling: true }, detail: "\u5E73\u677F\u76F4\u8FDE", tooltip: "ArkForge \u672C\u673A\u5DE5\u5177\uFF1B\u6A21\u578B\u63A8\u7406\u7531\u5E73\u677F\u76F4\u8FDE API" }];
        },
        provideTokenCount: async (model, text) => new TextEncoder().encode(typeof text === "string" ? text : JSON.stringify(text)).length,
        provideLanguageModelChatResponse: async (model, messages, options, progress, token) => {
          const converted = [];
          for (const message of messages) {
            const text = message.content.filter((part) => part instanceof vscode2.LanguageModelTextPart).map((part) => part.value).join("\n");
            const calls = message.content.filter((part) => part instanceof vscode2.LanguageModelToolCallPart);
            const results = message.content.filter((part) => part instanceof vscode2.LanguageModelToolResultPart);
            if (text || calls.length) converted.push({ role: message.role === vscode2.LanguageModelChatMessageRole.Assistant ? "assistant" : "user", content: text, ...calls.length ? { tool_calls: calls.map((call) => ({ id: call.callId, type: "function", function: { name: call.name, arguments: JSON.stringify(call.input) } })) } : {} });
            for (const result of results) converted.push({ role: "tool", tool_call_id: result.callId, content: result.content.filter((part) => part instanceof vscode2.LanguageModelTextPart).map((part) => part.value).join("\n") });
          }
          const definitions = (options.tools || []).map((tool) => ({ type: "function", function: { name: tool.name, description: tool.description, parameters: tool.inputSchema } }));
          const response = await query(converted, token, definitions.length ? { tools: definitions } : {});
          if (response.content) progress.report(new vscode2.LanguageModelTextPart(response.content));
          for (const call of response.tool_calls || []) progress.report(new vscode2.LanguageModelToolCallPart(call.id, call.function.name, JSON.parse(call.function.arguments || "{}")));
        }
      }));
      vscode2.lm.selectChatModels({ vendor: "arkforge-deepseek" }).then((models) => output.info("ArkForge\uFF1A\u539F\u751F Chat \u5DF2\u52A0\u8F7D " + models.length + " \u4E2A\u5E73\u677F\u76F4\u8FDE\u6A21\u578B"), (error) => output.error("\u6A21\u578B\u6CE8\u518C\u5931\u8D25\uFF1A" + error.message));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.resumeAgent", () => vscode2.commands.executeCommand("workbench.action.chat.open", { query: "\u7EE7\u7EED\u4E0A\u6B21\u4EFB\u52A1\uFF0C\u4ECE\u5DF2\u4FDD\u5B58\u7684\u8FDB\u5EA6\u7EE7\u7EED\u4FEE\u590D\u5E76\u9A8C\u8BC1\u3002" })));
      const participant = vscode2.chat.createChatParticipant("arkforge.agent", async (request, chatContext, stream, token) => {
        const direct = { build: "build_project", logs: "read_logs", file: "get_open_file", test: "test_build_workflow", guide: "build_guide", setup: "configure_agent" };
        if (request.command && direct[request.command]) {
          try {
            stream.progress("\u6B63\u5728\u6267\u884C " + request.command + "\u2026");
            const result = await (request.command === "test" ? vscode2.commands.executeCommand("arkforge.testBuildWorkflow") : request.command === "guide" ? vscode2.commands.executeCommand("arkforge.buildGuide") : request.command === "setup" ? vscode2.commands.executeCommand("arkforge.configureAgent") : vscode2.lm.invokeTool("arkforge_" + direct[request.command], { input: {}, toolInvocationToken: request.toolInvocationToken }, token).then((value) => value.content.filter((part) => part instanceof vscode2.LanguageModelTextPart).map((part) => part.value).join("\n")));
            if (result) stream.markdown("```text\n" + String(result).slice(-16e3) + "\n```");
            return {};
          } catch (error) {
            return { errorDetails: { message: error.message } };
          }
        }
        const workspaceUri = vscode2.workspace.workspaceFolders?.[0]?.uri;
        if (!workspaceUri) return { errorDetails: { message: "\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A HarmonyOS \u5DE5\u7A0B\uFF0C\u518D\u4F7F\u7528 Agent\u3002" } };
        const workspace = workspaceUri.toString();
        const settings = await config();
        if (!settings.hasKey) {
          stream.markdown("\u8BF7\u5148\u914D\u7F6E\u6A21\u578B API\u3002\u5DE5\u7A0B\u6587\u4EF6\u548C\u5168\u90E8\u5F00\u53D1\u5DE5\u5177\u5728\u5E73\u677F\u672C\u673A\u6267\u884C\u3002");
          stream.button({ command: "arkforge.configureAgent", title: "\u914D\u7F6E DeepSeek / \u6A21\u578B API" });
          stream.button({ command: "arkforge.build", title: "\u624B\u52A8\u7F16\u8BD1\u5B89\u88C5" });
          stream.button({ command: "arkforge.testBuildWorkflow", title: "\u6D4B\u8BD5\u672C\u673A\u6784\u5EFA\u6D41\u7A0B" });
          stream.button({ command: "arkforge.buildGuide", title: "\u67E5\u770B\u6784\u5EFA\u65B9\u6CD5" });
          return {};
        }
        const key = "arkforge.agent.checkpoint:" + workspace;
        const previous = [...chatContext.history].reverse().find((turn) => Array.isArray(turn.result?.metadata?.messages));
        const resume = /^(?:继续|接着|恢复|continue|resume)/i.test(request.prompt.trim());
        const saved = resume ? context.globalState?.get(key) : void 0;
        const history = previous?.result.metadata.workspace === workspace ? previous.result.metadata : void 0;
        const prior = resume && saved?.workspace === workspace && saved.taskState?.status !== "completed" ? saved : history;
        const messages = prior?.messages?.slice() || [];
        messages.push({ role: "user", content: request.prompt });
        try {
          for (const reference of (request.references || []).slice(0, 4)) {
            const uri = reference.value?.uri || reference.value;
            if (uri?.scheme === "arkforge" && uri.authority === vscode2.workspace.workspaceFolders[0].uri.authority) {
              const result = await agentTool("read_file", { path: uri.path.replace(/^\/workspace\//, ""), start_line: reference.value?.range?.start.line + 1 || 1 });
              messages.push({ role: "user", content: "\u9644\u52A0\u7684\u5DE5\u7A0B\u6587\u4EF6\uFF1A\n" + result });
              stream.reference(uri);
            }
          }
          const definitions = tools.map((tool) => ({ type: "function", function: { name: tool.name, description: tool.description, parameters: schema(tool) } }));
          const goal = resume ? prior?.taskState?.goal || prior?.messages?.find((message) => message.role === "user" && !/^(?:继续|接着|恢复|continue|resume)/i.test(message.content))?.content || request.prompt : request.prompt;
          return await runAgentTask({
            messages,
            workspace,
            goal,
            context: agentContext.settings(vscode2),
            state: resume ? prior?.taskState : void 0,
            token,
            stream,
            system: "\u4F60\u662F ArkForge \u5F53\u524D\u8BBE\u5907\u4E0A\u7684 HarmonyOS \u5F00\u53D1\u52A9\u624B\u3002\u6240\u6709\u5DE5\u5177\u5728\u672C\u673A\u6267\u884C\u3002\u5148\u8BFB\u53D6\u6E90\u7801\u548C\u7248\u672C\u518D\u7CBE\u786E\u4FEE\u6539\u3002\u4FEE\u6539\u5DF2\u6709\u6587\u4EF6\u4F18\u5148\u7CBE\u786E\u66FF\u6362\uFF0C\u4FDD\u7559\u516C\u5F00\u65B9\u6CD5\u3001\u6D4B\u8BD5\u5165\u53E3\u548C\u8C03\u7528\u65B9\u7EA6\u5B9A\uFF1B\u4FDD\u5B58\u6574\u4E2A\u6587\u4EF6\u524D\u5148\u5B8C\u6574\u8BFB\u53D6\u5F53\u524D\u7248\u672C\u3002\u6301\u7EED\u5B8C\u6210\u7528\u6237\u76EE\u6807\uFF0C\u53EF\u8DE8\u8D8A\u591A\u8F6E\u8BFB\u53D6\u3001\u641C\u7D22\u3001\u4FEE\u6539\u548C\u590D\u67E5\u3002\u5148\u7528 get_diagnostics(mode=summary) \u4E00\u6B21\u53D6\u5F97\u5168\u9879\u76EE\u8BCA\u65AD\uFF0C\u6309\u6587\u4EF6\u548C\u539F\u56E0\u5206\u7EC4\u89C4\u5212\uFF1B\u4F7F\u7528 read_files \u6279\u91CF\u8BFB\u53D6\u76F8\u5173\u6E90\u7801\uFF0C\u5C0F\u6587\u4EF6\u4E00\u6B21\u8BFB\u5B8C\u3002\u907F\u514D\u91CD\u590D\u7FFB\u9875\u548C\u53CD\u590D\u8BFB\u53D6\u76F8\u540C\u5185\u5BB9\u3002\u6BCF\u6279\u4FEE\u6539\u540E\u7F16\u8BD1\u5E76\u91CD\u65B0\u6C47\u603B\u8BCA\u65AD\u3002\u6E05\u7406\u6240\u6709 warnings \u65F6\u6309\u89C4\u5219\u548C\u6587\u4EF6\u5206\u7EC4\u9010\u9879\u4FEE\u590D\uFF0C\u4FDD\u6301\u68C0\u67E5\u89C4\u5219\u548C\u539F\u6709\u884C\u4E3A\uFF1B\u5148\u4FEE\u590D ERROR\u3002\u4EE5\u5F53\u524D\u6E90\u7801\u91CD\u65B0\u6784\u5EFA\u7684\u771F\u5B9E\u7ED3\u679C\u4E3A\u5B8C\u6210\u4F9D\u636E\u3002\u7528\u6237\u53EA\u8981\u6C42\u68C0\u67E5\u65F6\u4F7F\u7528 compile_project\uFF0C\u660E\u786E\u8981\u6C42\u5B89\u88C5\u624D\u4F7F\u7528 build_project\u3002\u5DE5\u5177\u9519\u8BEF\u5148\u8C03\u6574\u53C2\u6570\u6216\u8BFB\u53D6\u6700\u65B0\u7248\u672C\u7EE7\u7EED\u3002\u82E5\u786E\u9700\u7528\u6237\u63D0\u4F9B\u4FE1\u606F\uFF0C\u660E\u786E\u7ED9\u51FA\u8FDB\u5EA6\u548C\u6240\u9700\u4FE1\u606F\u3002",
            query: (messages2, token2) => query(messages2, token2, { tools: definitions }),
            diagnostics: async () => JSON.parse(await native("sdk_diagnostics")),
            checkpoint: context.globalState ? (data) => context.globalState.update(key, data) : void 0,
            invoke: async (name, input) => {
              const tool = tools.find((tool2) => tool2.name === name);
              if (!tool) throw new Error("\u6A21\u578B\u8BF7\u6C42\u4E86\u672A\u6CE8\u518C\u7684\u5DE5\u5177");
              stream.progress(tool.label + "\u2026");
              const value = await vscode2.lm.invokeTool("arkforge_" + name, { input, toolInvocationToken: request.toolInvocationToken }, token);
              const result = value.content.filter((part) => part instanceof vscode2.LanguageModelTextPart).map((part) => part.value).join("\n");
              if (input.path && ["read_file", "write_file", "replace_text"].includes(name)) stream.reference(vscode2.Uri.joinPath(vscode2.workspace.workspaceFolders[0].uri, input.path));
              output.info("Agent \u5DE5\u5177 " + name + "\uFF1A" + (/BUILD FAILED|^工具失败：/.test(result) ? "\u5931\u8D25" : "\u5DF2\u5B8C\u6210"));
              return result;
            }
          });
        } catch (error) {
          return { errorDetails: { message: error.message }, metadata: { messages, workspace } };
        }
      });
      participant.additionalWelcomeMessage = "\u4F7F\u7528\u5E73\u677F\u672C\u673A\u5DE5\u5177\u5F00\u53D1 HarmonyOS \u5DE5\u7A0B\u3002\u8F93\u5165 /build \u6784\u5EFA\u5B89\u88C5\uFF0C/test \u6D4B\u8BD5\u6D41\u7A0B\uFF0C/guide \u67E5\u770B\u65B9\u6CD5\uFF0C/setup \u914D\u7F6E\u6A21\u578B API\u3002";
      participant.iconPath = new vscode2.ThemeIcon("tools");
      participant.followupProvider = { provideFollowups: () => [
        { prompt: "\u7F16\u8BD1\u5E76\u5B89\u88C5\u5F53\u524D\u5DE5\u7A0B", command: "build", label: "\u672C\u673A\u6784\u5EFA\u5E76\u5B89\u88C5" },
        { prompt: "\u9A8C\u8BC1\u5F53\u524D\u5DE5\u7A0B\u7684\u6784\u5EFA\u5B89\u88C5\u6D41\u7A0B", command: "test", label: "\u6D4B\u8BD5\u6784\u5EFA\u6D41\u7A0B" },
        { prompt: "\u8BF4\u660E\u624B\u52A8\u6784\u5EFA\u5B89\u88C5\u7684\u64CD\u4F5C\u6B65\u9AA4", command: "guide", label: "\u6784\u5EFA\u65B9\u6CD5\u8BF4\u660E" }
      ] };
      context.subscriptions.push(participant);
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.openChat", () => vscode2.commands.executeCommand("workbench.action.chat.open")));
    };
  }
});

// workbench/extension/welcomeGuide.js
var require_welcomeGuide = __commonJS({
  "workbench/extension/welcomeGuide.js"(exports2) {
    var vscode2 = require("vscode");
    var welcomeKey = "arkforge.welcomeGuide.v1";
    exports2.registerWelcomeGuide = function(context) {
      const open = () => vscode2.commands.executeCommand("workbench.action.openWalkthrough", "arkforge.arkforge-device#arkforge.welcome");
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.usageGuide", open));
      context.subscriptions.push(vscode2.commands.registerCommand("arkforge.gitGuide", () => vscode2.commands.executeCommand("workbench.action.openWalkthrough", "arkforge.arkforge-device#arkforge.gitGuide")));
      const firstRun = (async () => {
        if (!context.globalState || context.globalState.get(welcomeKey)) return;
        await open();
        await context.globalState.update(welcomeKey, true);
      })();
      firstRun.catch((error) => vscode2.window.showErrorMessage("\u8BF7\u4ECE\u201C\u5E2E\u52A9 \u2192 ArkForge \u4F7F\u7528\u4ECB\u7ECD\u4E0E\u64CD\u4F5C\u6307\u5357\u201D\u6253\u5F00\u6B22\u8FCE\u9875\u3002" + error.message));
      return firstRun;
    };
  }
});

// workbench/extension/extension.js
var vscode = require("vscode");
exports.activate = function(context) {
  context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor((editor) => {
    if (editor) vscode.commands.executeCommand("arkforge.phone.revealEditor").catch(console.error);
  }));
  const rootUri = () => vscode.workspace.workspaceFolders?.[0]?.uri || vscode.Uri.parse("arkforge:/workspace");
  const native = async (method, args = {}) => vscode.commands.executeCommand("arkforge.native", method, args);
  const events = new vscode.EventEmitter();
  context.subscriptions.push(events);
  const fs = async (operation, uri, extra = {}) => {
    if (uri.authority !== rootUri().authority) throw vscode.FileSystemError.NoPermissions("\u6587\u4EF6\u5C5E\u4E8E\u5176\u4ED6\u5DE5\u7A0B\uFF0C\u8BF7\u5148\u6253\u5F00\u5BF9\u5E94\u5DE5\u7A0B");
    try {
      return await native("fs." + operation, { path: uri.path, ...extra });
    } catch (e) {
      if (/no such file|not exist|13900002/i.test(e.message)) throw vscode.FileSystemError.FileNotFound(uri);
      throw vscode.FileSystemError.Unavailable(e.message);
    }
  };
  const provider = {
    onDidChangeFile: events.event,
    watch: () => new vscode.Disposable(() => {
    }),
    stat: async (uri) => JSON.parse(await fs("stat", uri)),
    readDirectory: async (uri) => JSON.parse(await fs("list", uri)),
    readFile: async (uri) => Uint8Array.from(atob(await fs("read", uri)), (c) => c.charCodeAt(0)),
    writeFile: async (uri, content, options) => {
      let binary = "";
      for (let i = 0; i < content.length; i += 32768) binary += String.fromCharCode(...content.subarray(i, i + 32768));
      await fs("write", uri, { data: btoa(binary), ...options });
      events.fire([{ type: options.overwrite ? vscode.FileChangeType.Changed : vscode.FileChangeType.Created, uri }]);
    },
    createDirectory: async (uri) => {
      await fs("mkdir", uri);
      events.fire([{ type: vscode.FileChangeType.Created, uri }]);
    },
    delete: async (uri, options) => {
      await fs("delete", uri, options);
      events.fire([{ type: vscode.FileChangeType.Deleted, uri }]);
    },
    rename: async (from, to, options) => {
      if (to.authority !== rootUri().authority) throw vscode.FileSystemError.NoPermissions("\u76EE\u6807\u5C5E\u4E8E\u5176\u4ED6\u5DE5\u7A0B\uFF0C\u8BF7\u5148\u6253\u5F00\u5BF9\u5E94\u5DE5\u7A0B");
      await fs("rename", from, { target: to.path, ...options });
      events.fire([{ type: vscode.FileChangeType.Deleted, uri: from }, { type: vscode.FileChangeType.Created, uri: to }]);
    }
  };
  context.subscriptions.push(vscode.workspace.registerFileSystemProvider("arkforge", provider, { isCaseSensitive: true }));
  let taskProgress;
  const channel = vscode.window.createOutputChannel("ArkForge Build", "log");
  const output = { info: (text) => channel.appendLine(text), warn: (text) => channel.appendLine(text), error: (text) => channel.appendLine(text), show: (preserveFocus) => channel.show(preserveFocus) };
  const diagnostics = vscode.languages.createDiagnosticCollection("ArkForge SDK");
  context.subscriptions.push(diagnostics);
  context.subscriptions.push(channel);
  context.subscriptions.push(vscode.commands.registerCommand("arkforge.appendBuildLog", async (text) => {
    for (const line of text.split("\n")) {
      if (line.includes("> ArkForge :")) taskProgress?.report({ message: line.replace(/^.*> ArkForge :/, "") });
      if (line.includes("Started ")) diagnostics.clear();
      if (/\berror\b|BUILD FAILED/i.test(line)) output.error(line);
      else if (/\bwarning\b/i.test(line)) output.warn(line);
      else output.info(line);
      const match = line.match(/(?:^|\]\s+)([^\[\]\s].*?):(\d+):(\d+): (error|warning) ([A-Za-z]+\d+): (.*)/);
      if (match) {
        const uri = vscode.Uri.joinPath(rootUri(), match[1]);
        const diagnostic = new vscode.Diagnostic(new vscode.Range(Number(match[2]) - 1, Number(match[3]) - 1, Number(match[2]) - 1, Number(match[3])), match[6], match[4] === "error" ? vscode.DiagnosticSeverity.Error : vscode.DiagnosticSeverity.Warning);
        diagnostic.code = match[5];
        diagnostic.source = "HarmonyOS SDK";
        diagnostics.set(uri, [...diagnostics.get(uri) || [], diagnostic]);
      }
    }
    if (/BUILD (?:FAILED|SUCCESSFUL)/.test(text)) {
      let items;
      try {
        items = JSON.parse(await native("sdk_diagnostics"));
      } catch (error) {
        output.info(error.message);
        return;
      }
      diagnostics.clear();
      for (const item of items) {
        const relative = item.fileName.replace(/^\/project\//, "");
        if (!relative || relative.startsWith("/") || relative.split("/").includes("..") || item.line < 1 || item.column < 1) continue;
        const uri = vscode.Uri.joinPath(rootUri(), relative);
        const diagnostic = new vscode.Diagnostic(new vscode.Range(item.line - 1, item.column - 1, item.line - 1, item.column), item.message, item.category === 1 ? vscode.DiagnosticSeverity.Error : vscode.DiagnosticSeverity.Warning);
        diagnostic.code = item.code;
        diagnostic.source = "HarmonyOS SDK";
        diagnostics.set(uri, [...diagnostics.get(uri) || [], diagnostic]);
      }
    }
  }));
  require_projectRun().registerProjectRun(context, native, output, (progress) => {
    taskProgress = progress;
  });
  require_projectSearch().registerProjectSearch(context, native);
  require_gitTerminal().registerGitTerminal(context, native);
  require_developerSetup().registerDeveloperSetup(context, native);
  require_deviceDebug().registerDeviceDebug(context, native);
  context.subscriptions.push(vscode.commands.registerCommand("arkforge.importSigning", () => vscode.commands.executeCommand("arkforge.configureSigning")));
  const actions = { openProject: "open_project", exportProject: "export_project", launch: "run_app", logs: "read_logs", checkSDK: "check_sdk" };
  for (const [command, method] of Object.entries(actions)) {
    context.subscriptions.push(vscode.commands.registerCommand("arkforge." + command, async () => {
      try {
        if (["openProject", "exportProject"].includes(command) && !await vscode.workspace.saveAll(false)) throw new Error("\u6587\u4EF6\u4FDD\u5B58\u5931\u8D25\uFF0C\u5DE5\u7A0B\u64CD\u4F5C\u5DF2\u505C\u6B62");
        output.show(true);
        const result = await native(method, {});
        if (result) output.info(result);
        if (command === "openProject" && JSON.parse(result).changed) await vscode.commands.executeCommand("workbench.action.reloadWindow");
      } catch (e) {
        output.error(e.message);
        vscode.window.showErrorMessage(e.message);
      }
    }));
  }
  context.subscriptions.push(vscode.commands.registerCommand("arkforge.build", async () => {
    const selected = await vscode.window.showQuickPick([
      { label: "$(run-all) \u7F16\u8BD1\u5E76\u5B89\u88C5\u5F53\u524D\u5DE5\u7A0B", description: "\u5728\u6B64\u5E73\u677F\u5B8C\u6210\u7F16\u8BD1\u4E0E\u5B89\u88C5", action: "build" },
      { label: "$(key) \u9996\u6B21\u4F7F\u7528\uFF1A\u914D\u7F6E\u5F00\u53D1\u7B7E\u540D", description: "\u534E\u4E3A\u8D26\u53F7\u81EA\u52A8\u7B7E\u540D\u6216\u624B\u52A8\u5BFC\u5165\uFF0C\u540E\u7EED\u81EA\u52A8\u590D\u7528", action: "signing" },
      { label: "$(book) \u67E5\u770B\u6784\u5EFA\u65B9\u6CD5", description: "\u6253\u5F00\u5DE5\u7A0B \u2192 \u4FDD\u5B58 \u2192 \u7B7E\u540D \u2192 \u6784\u5EFA \u2192 \u8FD0\u884C", action: "guide" },
      { label: "$(beaker) \u9A8C\u8BC1\u6784\u5EFA\u64CD\u4F5C\u6D41\u7A0B", description: "\u5B9E\u9645\u6267\u884C SDK \u81EA\u68C0\u53CA\u5F53\u524D\u5DE5\u7A0B\u6784\u5EFA\u5B89\u88C5", action: "test" }
    ], { title: "ArkForge \xB7 \u624B\u52A8\u7F16\u8BD1\u5B89\u88C5", placeHolder: "\u9009\u62E9\u64CD\u4F5C\uFF1B\u9996\u6B21\u4F7F\u7528\u8BF7\u5148\u914D\u7F6E\u5F53\u524D\u5DE5\u7A0B\u548C\u8BBE\u5907\u7684\u5F00\u53D1\u7B7E\u540D" });
    if (!selected) return;
    if (selected.action === "signing") return vscode.commands.executeCommand("arkforge.configureSigning");
    if (selected.action === "guide") return vscode.commands.executeCommand("arkforge.buildGuide");
    if (selected.action === "test") return vscode.commands.executeCommand("arkforge.testBuildWorkflow");
    return vscode.commands.executeCommand("arkforge.run");
  }));
  const projectUri = (path) => {
    if (typeof path !== "string" || path.startsWith("/") || path.includes("\\") || path.split("/").some((part) => part === ".." || part === "." || !part)) throw new Error("\u8BF7\u4F7F\u7528\u5DE5\u7A0B\u5185\u7684\u76F8\u5BF9\u6587\u4EF6\u8DEF\u5F84");
    return vscode.Uri.joinPath(rootUri(), path);
  };
  const readCoverage = /* @__PURE__ */ new Map();
  function recordRead(path, version, start, end, total) {
    const old = readCoverage.get(path), ranges = old?.version === version ? old.ranges : [];
    ranges.push([start, end]);
    ranges.sort((a, b) => a[0] - b[0]);
    const merged = [];
    for (const range of ranges) {
      const last = merged[merged.length - 1];
      if (last && range[0] <= last[1] + 1) last[1] = Math.max(last[1], range[1]);
      else merged.push(range.slice());
    }
    readCoverage.set(path, { version, ranges: merged, complete: merged[0]?.[0] === 1 && merged[0][1] >= total });
    if (readCoverage.size > 100) readCoverage.delete(readCoverage.keys().next().value);
  }
  async function agentTool(method, args) {
    if (method === "read_file") {
      const document = await vscode.workspace.openTextDocument(projectUri(args.path));
      if (document.getText().length > 2 * 1024 * 1024) throw new Error("\u6587\u4EF6\u8D85\u8FC7 2 MB");
      const lines = document.getText().replace(/\r+\n/g, "\n").split("\n");
      const start = Math.max(1, Number(args.start_line) || 1);
      const end = Math.min(lines.length, start + 1199, Number(args.end_line) || start + 599);
      const selected = [];
      let size = 0;
      const budget = Math.max(1e3, Math.min(24e3, Number(args._budget) || 24e3));
      for (let line = start; line <= end; line++) {
        const text = lines[line - 1];
        if (size + JSON.stringify(text).length > budget) break;
        selected.push(text);
        size += JSON.stringify(text).length + 1;
      }
      const actualEnd = start + selected.length - 1;
      recordRead(args.path, document.version, start, actualEnd, lines.length);
      return JSON.stringify({ path: args.path, version: document.version, start_line: start, end_line: actualEnd, total_lines: lines.length, content: selected.join("\n"), truncated: actualEnd < end, ...actualEnd < lines.length ? { next_line: Math.max(start, actualEnd + 1) } : {} });
    }
    if (method === "read_files") {
      if (!Array.isArray(args.files) || !args.files.length || args.files.length > 6) throw new Error("\u8BF7\u9009\u62E9 1 \u81F3 6 \u4E2A\u5DE5\u7A0B\u6587\u4EF6");
      const results = [];
      for (const file of args.files) {
        try {
          results.push(JSON.parse(await agentTool("read_file", { ...file, _budget: Math.floor(28e3 / args.files.length) })));
        } catch (error) {
          results.push({ path: file.path, error: error.message });
        }
      }
      return JSON.stringify({ files: results });
    }
    if (method === "write_file" || method === "replace_text") {
      const uri = projectUri(args.path);
      let document;
      let exists = true;
      try {
        await vscode.workspace.fs.stat(uri);
      } catch (e) {
        if (args.expected_version !== 0 || e.code !== "FileNotFound") throw e;
        exists = false;
      }
      if (exists) document = await vscode.workspace.openTextDocument(uri);
      if (document && document.version !== args.expected_version) throw new Error("\u6587\u4EF6\u7248\u672C\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u540E\u4FEE\u6539\uFF0C\u907F\u514D\u8986\u76D6\u7528\u6237\u7F16\u8F91");
      if (document && method === "write_file" && !(readCoverage.get(args.path)?.version === document.version && readCoverage.get(args.path)?.complete)) throw new Error("\u8BF7\u5148\u5B8C\u6574\u8BFB\u53D6\u5F53\u524D\u7248\u672C\uFF0C\u518D\u4FDD\u5B58\u6574\u4E2A\u6587\u4EF6\uFF1B\u5C40\u90E8\u4FEE\u6539\u53EF\u4F7F\u7528 replace_text\u3002");
      if (!document) {
        if (method !== "write_file" || typeof args.content !== "string") throw new Error("\u65B0\u6587\u4EF6\u9700\u8981 write_file \u548C\u5B8C\u6574\u5185\u5BB9");
        await vscode.workspace.fs.createDirectory(vscode.Uri.joinPath(uri, ".."));
        await provider.writeFile(uri, new TextEncoder().encode(args.content), { create: true, overwrite: false });
      } else {
        const text = document.getText();
        let start = 0, end = text.length, replacement = args.content;
        if (method === "replace_text") {
          if (typeof args.old_text !== "string" || !args.old_text) throw new Error("\u8BF7\u63D0\u4F9B\u5F85\u66FF\u6362\u7684\u6E90\u7801\u5185\u5BB9");
          const match = require_textEdits().locateUnique(text, args.old_text);
          start = match.start;
          end = match.end;
          replacement = args.new_text;
        }
        if (typeof replacement !== "string" || replacement.length > 2 * 1024 * 1024) throw new Error("\u5199\u5165\u5185\u5BB9\u65E0\u6548\u6216\u8FC7\u5927");
        if (method === "write_file") require_textEdits().assertPublicMethodsRetained(text, replacement);
        const edit = new vscode.WorkspaceEdit();
        edit.replace(uri, new vscode.Range(document.positionAt(start), document.positionAt(end)), replacement);
        if (!await vscode.workspace.applyEdit(edit)) throw new Error("\u7F16\u8F91\u5668\u62D2\u7EDD\u4FEE\u6539");
        if (!await document.save()) throw new Error("\u4FDD\u5B58\u5931\u8D25\uFF0C\u4FEE\u6539\u4ECD\u4FDD\u7559\u5728\u7F16\u8F91\u5668\u4E2D");
      }
      const saved = await vscode.workspace.openTextDocument(uri);
      await vscode.window.showTextDocument(saved, { preview: false, preserveFocus: true });
      return JSON.stringify({ ok: true, path: args.path, version: saved.version });
    }
    if (method === "create_directory") {
      await vscode.workspace.fs.createDirectory(projectUri(args.path));
      return JSON.stringify({ ok: true, path: args.path });
    }
    if (method === "rename_file" || method === "delete_file") {
      const uri = projectUri(args.path), stat = await vscode.workspace.fs.stat(uri);
      if (stat.type !== 1) throw new Error("\u8BF7\u9009\u62E9\u5DE5\u7A0B\u4E2D\u7684\u666E\u901A\u6587\u4EF6");
      const document = await vscode.workspace.openTextDocument(uri);
      if (document.version !== args.expected_version) throw new Error("\u8BF7\u91CD\u65B0\u8BFB\u53D6\u5F53\u524D\u6587\u4EF6\u53CA\u7248\u672C\u540E\u7EE7\u7EED\u64CD\u4F5C");
      if (document.isDirty && !await document.save()) throw new Error("\u8BF7\u5148\u5B8C\u6210\u5F53\u524D\u6587\u4EF6\u4FDD\u5B58");
      if (method === "rename_file") await vscode.workspace.fs.rename(uri, projectUri(args.new_path), { overwrite: false });
      else await vscode.workspace.fs.delete(uri, { recursive: false });
      return JSON.stringify({ ok: true, path: args.path, ...method === "rename_file" ? { new_path: args.new_path } : {} });
    }
    if (method === "get_diagnostics") {
      const all = JSON.parse(await native("sdk_diagnostics"));
      const selected = all.filter((item) => (!args.path || item.fileName.replace(/^\/project\//, "") === args.path) && (!args.category || item.category === (args.category === "warning" ? 0 : 1)));
      const counts = { total: all.length, errors: all.filter((item) => item.category === 1).length, warnings: all.filter((item) => item.category === 0).length, matched: selected.length };
      if (args.mode !== "details" && args.offset === void 0 && args.limit === void 0 || args.mode === "summary") {
        const groups = /* @__PURE__ */ new Map();
        for (const item of selected) {
          const path = item.fileName.replace(/^\/project\//, ""), key = JSON.stringify([path, item.category, item.code, item.message]);
          if (!groups.has(key)) groups.set(key, { path, category: item.category === 1 ? "error" : "warning", code: item.code, message: item.message, locations: [] });
          groups.get(key).locations.push([item.line, item.column]);
        }
        return JSON.stringify({ ...counts, mode: "summary", complete: true, groups: [...groups.values()], instruction: "\u5168\u90E8\u5339\u914D\u8BCA\u65AD\u5DF2\u6C47\u603B\uFF1Blocations \u5305\u542B\u6BCF\u4E00\u5904\u884C\u5217\u4F4D\u7F6E\u3002\u540C\u4E00\u539F\u56E0\u53EA\u663E\u793A\u4E00\u6B21\u3002\u6309\u6587\u4EF6\u6279\u91CF\u8BFB\u53D6\u6E90\u7801\u5E76\u4FEE\u590D\uFF0C\u4FEE\u6539\u540E\u91CD\u65B0\u6784\u5EFA\u3002" });
      }
      const offset = Math.max(0, Number(args.offset) || 0), limit = Math.max(1, Math.min(200, Number(args.limit) || 100));
      return JSON.stringify({ ...counts, mode: "details", offset, has_more: offset + limit < selected.length, diagnostics: selected.slice(offset, offset + limit) });
    }
    if (method === "list_dir") {
      const uri = !args.path || args.path === "." ? rootUri() : projectUri(args.path);
      return JSON.stringify(await vscode.workspace.fs.readDirectory(uri));
    }
    if (method === "get_open_file") {
      const editor = vscode.window.activeTextEditor;
      if (editor && (editor.document.uri.scheme !== "arkforge" || editor.document.uri.authority !== rootUri().authority)) throw new Error("\u8BF7\u5148\u6253\u5F00\u5F53\u524D\u5DE5\u7A0B\u4E2D\u7684\u6587\u4EF6");
      return JSON.stringify({ path: editor?.document.uri.path.replace(/^\/workspace\//, "") || "", version: editor?.document.version || 0, content: editor?.document.getText() || "" });
    }
    if (method === "build_project" || method === "compile_project") {
      if (!await vscode.workspace.saveAll(false)) throw new Error("\u8BF7\u5B8C\u6210\u6587\u4EF6\u4FDD\u5B58\u540E\u91CD\u65B0\u6784\u5EFA");
      output.show(true);
    }
    return await native(method, args);
  }
  require_buildWorkflow().registerBuildWorkflow(context, native, output);
  require_nativeChat().registerNativeChat(context, native, agentTool, output);
  require_welcomeGuide().registerWelcomeGuide(context);
};
